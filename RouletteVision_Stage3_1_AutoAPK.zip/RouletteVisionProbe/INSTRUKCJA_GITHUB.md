# Aktualizacja Roulette Vision PRO 3.1

Wgraj do repozytorium GitHub `Gpt` plik `RouletteVision_Stage3_1_AutoAPK.zip`, a w `.github/workflows/build-apk.yml` zamień linię rozpakowywania na:

```yaml
      - name: Rozpakuj projekt
        run: unzip -q RouletteVision_Stage3_1_AutoAPK.zip
```

Zatwierdź przez `Commit changes`. Po zakończeniu zadania w **Actions** pobierz artefakt **RouletteVision-APK** i rozpakuj zawarty w nim instalator `app-debug.apk`.
