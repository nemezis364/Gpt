package pl.roulette.visionprobe;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** All journal state stays local; nothing is sent to any server. */
public final class PredictionEngine {
    private static final String KEY="roulette_prediction_engine_v3";
    private final SharedPreferences prefs;
    private final ArrayList<Integer> spins=new ArrayList<>();
    private final ArrayList<String> dealerTags=new ArrayList<>();
    private final ArrayList<Ticket> tickets=new ArrayList<>();
    private final ArrayList<String> dealers=new ArrayList<>();
    private String selected="Auto Roulette";
    private String lastSource="brak";
    private String lastRead="—";
    private long revision=0;
    private static class Ticket {
        int index,actual=-1; String dealer;int[] centers,numbers;boolean visible;
        JSONObject json(){
            JSONObject j=new JSONObject();try{j.put("index",index);j.put("actual",actual);j.put("dealer",dealer);j.put("visible",visible);j.put("centers",array(centers));j.put("numbers",array(numbers));}catch(Exception ignored){}
            return j;
        }
    }
    private static JSONArray array(int[] xs){JSONArray a=new JSONArray();for(int x:xs)a.put(x);return a;}
    private static int[] ints(JSONArray arr){if(arr==null)return new int[0];int[] a=new int[arr.length()];for(int i=0;i<a.length;i++)a[i]=arr.optInt(i,-1);return a;}
    public PredictionEngine(Context ctx){prefs=ctx.getSharedPreferences(KEY,Context.MODE_PRIVATE);load();}
    private synchronized void load(){
        spins.clear();dealerTags.clear();tickets.clear();dealers.clear();
        try{
            JSONObject o=new JSONObject(prefs.getString("state","{}"));
            JSONArray d=o.optJSONArray("dealers");if(d!=null)for(int i=0;i<d.length();i++){String v=d.optString(i,"");if(!v.isEmpty()&&!dealers.contains(v))dealers.add(v);}
            if(!dealers.contains("Auto Roulette"))dealers.add(0,"Auto Roulette");
            selected=o.optString("selected","Auto Roulette");if(!dealers.contains(selected))selected="Auto Roulette";
            JSONArray a=o.optJSONArray("spins"),tags=o.optJSONArray("tags");
            if(a!=null)for(int i=0;i<a.length();i++){
                int n=a.optInt(i,-1);if(ForecastMath.valid(n)){spins.add(n);dealerTags.add(tags==null?"Auto Roulette":tags.optString(i,"Auto Roulette"));}
            }
            JSONArray t=o.optJSONArray("tickets");if(t!=null)for(int i=0;i<t.length();i++){
                JSONObject v=t.optJSONObject(i);if(v==null)continue;Ticket z=new Ticket();
                z.index=v.optInt("index",-1);z.actual=v.optInt("actual",-1);z.dealer=v.optString("dealer","Auto Roulette");z.visible=v.optBoolean("visible",false);
                z.centers=ints(v.optJSONArray("centers"));z.numbers=ints(v.optJSONArray("numbers"));
                if(z.index<0||z.index>spins.size()||z.centers.length!=3||z.numbers.length!=15)continue;
                if(z.actual>=0&&(z.index>=spins.size()||z.actual!=spins.get(z.index)))continue;
                tickets.add(z);
            }
            lastSource=o.optString("source","brak");lastRead=o.optString("read","—");revision=o.optLong("revision",0);
        }catch(Exception ignored){ }
        if(dealers.isEmpty())dealers.add("Auto Roulette");
        ensurePending();
    }
    private synchronized void save(){
        JSONObject o=new JSONObject();try{
            JSONArray a=new JSONArray();for(int n:spins)a.put(n);o.put("spins",a);
            JSONArray t=new JSONArray();for(String v:dealerTags)t.put(v);o.put("tags",t);
            JSONArray d=new JSONArray();for(String v:dealers)d.put(v);o.put("dealers",d);
            JSONArray j=new JSONArray();for(Ticket v:tickets)j.put(v.json());o.put("tickets",j);
            o.put("selected",selected);o.put("source",lastSource);o.put("read",lastRead);o.put("revision",++revision);
        }catch(Exception ignored){}
        prefs.edit().putString("state",o.toString()).apply();
    }
    public synchronized long revision(){return revision;}
    public synchronized String getSelected(){return selected;}
    public synchronized List<String> dealerNames(){return new ArrayList<>(dealers);}
    public synchronized void selectDealer(String name){if(dealers.contains(name)){selected=name;ensurePending();save();}}
    public synchronized void addDealer(String name){name=name.trim();if(name.length()>32)name=name.substring(0,32);if(!name.isEmpty()&&!dealers.contains(name)){dealers.add(name);selected=name;ensurePending();save();}}
    public synchronized int count(){return spins.size();}
    public synchronized String getLastRead(){return lastRead;}
    public synchronized void noteOcr(String label){lastRead=label;prefs.edit().putString("ocr_label",label).apply();}
    private void ensurePending(){
        int index=spins.size();
        Ticket existing=null;for(Ticket t:tickets)if(t.index==index&&t.actual<0){existing=t;break;}
        if(existing!=null && existing.dealer.equals(selected))return;
        if(existing!=null)tickets.remove(existing);
        if(index==0)return;
        int[] raw=ForecastMath.historyCenters(spins.get(index-1),spins,index);
        if(raw==null)return;
        int[] centers=ForecastMath.noOverlap(raw);
        if(centers==null)return;
        Ticket t=new Ticket();t.index=index;t.dealer=selected;t.centers=centers;t.numbers=ForecastMath.sectorNumbers(centers);t.visible=gate().qualified;
        tickets.add(t);
    }
    public synchronized boolean record(int n,String source){
        if(!ForecastMath.valid(n))return false;
        ensurePending();
        for(Ticket t:tickets)if(t.index==spins.size() && t.actual<0)t.actual=n;
        spins.add(n);dealerTags.add(selected);lastSource=source;
        ensurePending();save();return true;
    }
    public synchronized boolean undo(){
        if(spins.isEmpty())return false;
        spins.remove(spins.size()-1);
        String old=dealerTags.remove(dealerTags.size()-1);
        if(dealers.contains(old))selected=old;
        int newCount=spins.size();
        tickets.removeIf(t->t.index>newCount);
        for(Ticket t:tickets)if(t.index==newCount)t.actual=-1;
        lastSource="cofnięto";ensurePending();save();return true;
    }
    private static class Gate{int trials,hits;boolean qualified;}
    private Gate gate(){
        Gate g=new Gate();
        for(int i=tickets.size()-1;i>=0&&g.trials<6;i--){
            Ticket t=tickets.get(i);if(t.actual<0||!selected.equals(t.dealer))continue;
            g.trials++;for(int n:t.numbers)if(n==t.actual){g.hits++;break;}
        }
        g.qualified=g.trials>=6&&g.hits>=3;return g;
    }
    private Ticket pending(){for(Ticket t:tickets)if(t.index==spins.size()&&t.actual<0&&selected.equals(t.dealer))return t;return null;}
    public synchronized String summary(){
        ForecastMath.Top top=ForecastMath.top1(spins,spins.size());Gate g=gate();Ticket p=pending();
        StringBuilder s=new StringBuilder();
        s.append("ROULETTE VISION 3.1\n");
        s.append("Ostatni wynik: ").append(spins.isEmpty()?"—":spins.get(spins.size()-1)).append("  |  spinów: ").append(spins.size()).append("\n");
        if(top!=null&&top.number>=0)s.append("TOP 1 CCW: ").append(top.number).append("  |  odległość ").append(top.distance).append(" (4 przejścia)\n");
        else s.append("TOP 1 CCW: potrzeba 5 wyników\n");
        s.append("3×5: ").append(g.trials).append("/6 ocen, ").append(g.hits).append(" trafień");
        if(p==null)s.append(" · brak dopasowania w historii\n");
        else if(!p.visible)s.append(" · UKRYTE (minimum 3/6)\n");
        else{
            s.append(" · AKTYWNE\n");
            for(int i=0;i<3;i++){
                int[] ns=ForecastMath.neighbors(p.centers[i]);
                s.append("S").append(i+1).append(" [");for(int k=0;k<5;k++){if(k>0)s.append(" ");s.append(ns[k]);}s.append("]\n");
            }
        }
        int dozen=ForecastMath.hotDozen(spins,12);
        int par=ForecastMath.hotParity(spins,12);
        s.append("Tuzin (ostatnie 12): ").append(dozen==0?"brak":(dozen==1?"1–12":dozen==2?"13–24":"25–36")).append("\n");
        s.append("Parzystość (ostatnie 12): ").append(par==-1?"brak":par==0?"PARZYSTE":"NIEPARZYSTE").append("\n");
        s.append("Odczyt: ").append(lastRead).append("  |  dodano: ").append(lastSource);
        return s.toString();
    }
    public synchronized String overlay(){
        ForecastMath.Top top=ForecastMath.top1(spins,spins.size());Ticket p=pending();Gate g=gate();
        StringBuilder s=new StringBuilder("VISION 3.1  |  "+selected+"\n");
        s.append("TOP1 CCW: ").append(top==null||top.number<0?"—":top.number).append("  ·  3×5: ").append(g.trials>=6?g.hits+"/6":"test "+g.trials+"/6").append("\n");
        if(p!=null&&p.visible){for(int i=0;i<3;i++){
            s.append("S").append(i+1).append(": ");for(int n:ForecastMath.neighbors(p.centers[i]))s.append(n).append(" ");
            s.append("\n");
        }}else s.append("Sektory: ").append(p==null?"brak wzorca":"ukryte <3/6").append("\n");
        int dozen=ForecastMath.hotDozen(spins,12),par=ForecastMath.hotParity(spins,12);
        s.append("Tuzin: ").append(dozen==1?"1–12":dozen==2?"13–24":dozen==3?"25–36":"—");
        s.append("   ").append(par==-1?"—":par==0?"PARZ":"NIEPARZ");
        return s.toString();
    }
    public synchronized String recent(){
        StringBuilder out=new StringBuilder();
        for(int i=spins.size()-1;i>=Math.max(0,spins.size()-25);i--){if(out.length()>0)out.append(" · ");out.append(spins.get(i));}
        return out.length()==0?"Brak wyników":out.toString();
    }
    public synchronized boolean importJson(String text){
        try{
            Object data=new org.json.JSONTokener(text).nextValue();
            JSONArray a=data instanceof JSONArray?(JSONArray)data:((JSONObject)data).optJSONArray("spins");
            if(a==null)return false;
            ArrayList<Integer> ns=new ArrayList<>();for(int i=0;i<a.length();i++){Object item=a.get(i);if(!(item instanceof Integer))return false;int n=(Integer)item;if(!ForecastMath.valid(n))return false;ns.add(n);}
            spins.clear();spins.addAll(ns);dealerTags.clear();for(int n:ns)dealerTags.add(selected);
            tickets.clear();lastSource="import JSON — bez rozliczeń historycznych";
            // Old HTML browser storage cannot be read automatically by this APK.
            ensurePending();save();return true;
        }catch(Exception e){return false;}
    }
}
