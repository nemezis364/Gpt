package pl.roulette.visionprobe;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.Image;
import android.os.SystemClock;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.regex.Pattern;

/**
 * Read ONLY the specially highlighted most recent result, not the betting table or ball.
 * In Coldbet portrait mode the tile is at the TOP LEFT of the results strip.
 * In landscape mode Coldbet sometimes centres the strip and may move it upwards.
 *
 * Stage 3.1: find the actual coloured tile first (red / green / grey), then OCR its digit.
 * Local on-device recognition; no screenshot or extracted text is uploaded anywhere.
 */
public final class ResultOcr {
    public interface Listener {
        void onRead(int number, String stripSignature, String diagnostic);
        void onUncertain(String diagnostic);
    }

    private static final Pattern EXACT_NUMBER = Pattern.compile("(?:[0-9]|[12][0-9]|3[0-6])");
    private final TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private final Listener listener;
    private volatile boolean busy=false;
    private long lastAttempt=0;

    public ResultOcr(Listener listener){this.listener=listener;}

    private static final class Highlight {
        final Rect bounds;
        final double fill;
        Highlight(Rect bounds,double fill){this.bounds=bounds;this.fill=fill;}
    }
    private static final class Crop {
        final Bitmap picture;
        final Rect highlightInPicture;
        Crop(Bitmap bitmap,Rect area){picture=bitmap;highlightInPicture=area;}
    }

    public void capture(Image image){
        long now=SystemClock.elapsedRealtime();
        if(busy||now-lastAttempt<680)return;
        lastAttempt=now;busy=true;
        try{
            Highlight highlight=findHighlightedResult(image);
            if(highlight==null){
                listener.onUncertain("Czekam na wyróżniony numer w górnym pasku Coldbet");
                busy=false;return;
            }
            // Make the single-number crop the PRIMARY OCR input. This avoids readings
            // from the animated result, sector numbers, balance or the betting grid.
            Crop numberCrop=cropImage(image,highlight.bounds,8,4);
            Crop rowCrop=cropResultsRow(image,highlight.bounds);
            if(numberCrop==null||rowCrop==null){recycle(numberCrop);recycle(rowCrop);busy=false;return;}
            String signature=signatureOfHistory(image,highlight.bounds);
            recognizer.process(InputImage.fromBitmap(numberCrop.picture,0))
                .addOnSuccessListener(text->{
                    Integer number=readNumber(text,null);
                    if(number!=null){
                        listener.onRead(number,number+"|"+signature,
                            "GÓRNY PASEK: "+number+" · pole "+rectText(highlight.bounds));
                        finish(numberCrop,rowCrop);
                    }else{
                        // Some phones' OCR misses a single glyph. Second pass uses
                        // the full results row, but accepts text INSIDE the tile only.
                        recognizer.process(InputImage.fromBitmap(rowCrop.picture,0))
                            .addOnSuccessListener(full->{
                                Integer fromRow=readNumber(full,rowCrop.highlightInPicture);
                                if(fromRow==null)listener.onUncertain("Widać pole wyniku, ale nie odczytano jego cyfry");
                                else listener.onRead(fromRow,fromRow+"|"+signature,
                                        "GÓRNY PASEK: "+fromRow+" · pole "+rectText(highlight.bounds));
                            })
                            .addOnFailureListener(error->listener.onUncertain("OCR paska: "+error.getClass().getSimpleName()))
                            .addOnCompleteListener(t->finish(numberCrop,rowCrop));
                    }
                })
                .addOnFailureListener(error->{
                    listener.onUncertain("OCR pola: "+error.getClass().getSimpleName());
                    finish(numberCrop,rowCrop);
                });
        }catch(Exception e){busy=false;listener.onUncertain("Błąd pola wyniku: "+e.getClass().getSimpleName());}
    }

    private static void recycle(Crop a){if(a!=null&&!a.picture.isRecycled())a.picture.recycle();}
    private void finish(Crop a,Crop b){recycle(a);recycle(b);busy=false;}
    private static String rectText(Rect r){return r.left+","+r.top+" "+r.width()+"×"+r.height();}

    private static Integer parseNumber(String str){
        String s=str.trim().replace('O','0').replace('o','0');
        if(s.equals("I")||s.equals("l")||s.equals("|"))s="1";
        if(!EXACT_NUMBER.matcher(s).matches())return null;
        try{return Integer.parseInt(s);}catch(NumberFormatException e){return null;}
    }
    private static Integer readNumber(Text result,Rect target){
        Integer found=null;
        double best=Double.POSITIVE_INFINITY;
        for(Text.TextBlock block:result.getTextBlocks())
            for(Text.Line line:block.getLines())
                for(Text.Element element:line.getElements()){
                    Integer n=parseNumber(element.getText());
                    Rect box=element.getBoundingBox();
                    if(n==null||box==null)continue;
                    if(target==null){
                        // The isolated box is expected to contain one unique number.
                        // A conflicting reading is ambiguous: do NOT save a guess.
                        if(found!=null&&!found.equals(n))return null;
                        found=n;
                    }else{
                        int margin=Math.max(9,target.height()/4);
                        if(box.centerX()<target.left-margin||box.centerX()>target.right+margin||
                            box.centerY()<target.top-margin||box.centerY()>target.bottom+margin)continue;
                        double dx=Math.abs(box.centerX()-target.centerX());
                        if(dx<best){found=n;best=dx;}
                    }
                }
        return found;
    }
    /** Scan only the top result strip. A solid coloured tile is unique in this region. */
    private static Highlight findHighlightedResult(Image image){
        int w=image.getWidth(),h=image.getHeight();if(w<250||h<350)return null;
        Image.Plane[] planes=image.getPlanes();if(planes.length==0)return null;
        ByteBuffer b=planes[0].getBuffer();int pixelStride=planes[0].getPixelStride(),rowStride=planes[0].getRowStride();
        if(pixelStride<3)return null;
        boolean portrait=h>w;
        int x0=portrait?0:(int)(w*.38), x1=(int)(w*(portrait?.30:.68));
        int y0=portrait?(int)(h*.05):0, y1=(int)(h*(portrait?.22:.34));
        int step=2, gw=(x1-x0+step-1)/step, gh=(y1-y0+step-1)/step;
        if(gw<10||gh<10)return null;
        byte[] mask=new byte[gw*gh],seen=new byte[gw*gh];int limit=b.limit();
        for(int sy=0;sy<gh;sy++)for(int sx=0;sx<gw;sx++){
            int px=x0+sx*step,py=y0+sy*step,p=py*rowStride+px*pixelStride;
            if(p+2>=limit)continue;
            int r=b.get(p)&255,g=b.get(p+1)&255,bl=b.get(p+2)&255;
            boolean red=r>95&&r>g*1.40&&r>bl*1.35&&g<125;
            boolean green=g>70&&g>r*1.17&&g>bl*1.12;
            boolean grey=r>70&&g>70&&bl>70&&Math.abs(r-g)<26&&Math.abs(r-bl)<26;
            if(red||green||grey)mask[sy*gw+sx]=1;
        }
        Highlight best=null;double bestScore=Double.NEGATIVE_INFINITY;
        int[] queue=new int[gw*gh];
        for(int i=0;i<mask.length;i++){
            if(mask[i]==0||seen[i]!=0)continue;
            int head=0,tail=0;queue[tail++]=i;seen[i]=1;
            int area=0,minX=gw,maxX=0,minY=gh,maxY=0;
            while(head<tail){
                int p=queue[head++],x=p%gw,y=p/gw;area++;
                minX=Math.min(minX,x);maxX=Math.max(maxX,x);
                minY=Math.min(minY,y);maxY=Math.max(maxY,y);
                for(int yy=Math.max(0,y-1);yy<=Math.min(gh-1,y+1);yy++)
                    for(int xx=Math.max(0,x-1);xx<=Math.min(gw-1,x+1);xx++){
                        int k=yy*gw+xx;if(mask[k]!=0&&seen[k]==0){seen[k]=1;queue[tail++]=k;}
                    }
            }
            int bw=(maxX-minX+1)*step,bh=(maxY-minY+1)*step;
            if(area<60||bw<32||bw>140||bh<18||bh>63)continue;
            double ratio=(double)bw/bh,fill=area/(double)((maxX-minX+1)*(maxY-minY+1));
            if(ratio<1.35||ratio>5.6||fill<.42)continue;
            int left=x0+minX*step,top=y0+minY*step;
            double expectedX=portrait?w*.055:w*.515;
            double distance=Math.abs(left+bw/2.0-expectedX)/w;
            double score=fill*3.0-distance*5.0-Math.abs(bh-32)*.008;
            // In landscape, prefer the row with selected result over lower roulette sectors.
            score-=top/(double)h*.07;
            if(score>bestScore){
                bestScore=score;
                best=new Highlight(new Rect(left,top,Math.min(w,left+bw),Math.min(h,top+bh)),fill);
            }
        }
        return best;
    }

    /** Copy selected tile to a large bitmap. No screenshot is persisted to storage. */
    private static Crop cropImage(Image image,Rect tile,int padding,int zoom){
        int w=image.getWidth(),h=image.getHeight();
        int x0=Math.max(0,tile.left-padding),y0=Math.max(0,tile.top-padding);
        int x1=Math.min(w,tile.right+padding),y1=Math.min(h,tile.bottom+padding);
        return copyImage(image,x0,y0,x1,y1,zoom,tile);
    }
    /** Second-pass OCR: the same highlight plus next results in the history row. */
    private static Crop cropResultsRow(Image image,Rect tile){
        int w=image.getWidth(),h=image.getHeight();
        int x0=Math.max(0,tile.left-8),y0=Math.max(0,tile.top-9);
        int x1=Math.min(w,tile.right+Math.min(390,(int)(w*.65)));
        int y1=Math.min(h,tile.bottom+9);
        return copyImage(image,x0,y0,x1,y1,3,tile);
    }
    private static Crop copyImage(Image image,int x0,int y0,int x1,int y1,int zoom,Rect tile){
        if(x1<=x0||y1<=y0)return null;
        Image.Plane[] ps=image.getPlanes();if(ps.length==0)return null;
        ByteBuffer b=ps[0].getBuffer();int pix=ps[0].getPixelStride(),row=ps[0].getRowStride(),limit=b.limit();
        int ww=x1-x0,hh=y1-y0;int[] pixels=new int[ww*hh];
        for(int y=0;y<hh;y++)for(int x=0;x<ww;x++){
            int pos=(y+y0)*row+(x+x0)*pix;
            if(pos+2>=limit)continue;
            int r=b.get(pos)&255,g=b.get(pos+1)&255,bl=b.get(pos+2)&255;
            pixels[y*ww+x]=0xFF000000|(r<<16)|(g<<8)|bl;
        }
        Bitmap base=Bitmap.createBitmap(ww,hh,Bitmap.Config.ARGB_8888);
        base.setPixels(pixels,0,ww,0,0,ww,hh);
        Bitmap scaled=Bitmap.createScaledBitmap(base,ww*zoom,hh*zoom,false);
        base.recycle();
        Rect local=new Rect((tile.left-x0)*zoom,(tile.top-y0)*zoom,
                (tile.right-x0)*zoom,(tile.bottom-y0)*zoom);
        return new Crop(scaled,local);
    }

    /**
     * A coarse stable visual signature of the HISTORY IMMEDIATELY AFTER the selected tile.
     * This distinguishes consecutive rounds with the same winning number. The ROI is a
     * static text strip; quantization suppresses slight video-compression variations.
     */
    private static String signatureOfHistory(Image image,Rect highlight){
        int w=image.getWidth(),h=image.getHeight();
        int from=Math.min(w-1,highlight.right+4),to=Math.min(w,from+Math.min(350,w/2));
        int y0=Math.max(0,highlight.top+2),y1=Math.min(h,highlight.bottom-2);
        if(from>=to||y0>=y1)return "EMPTY";
        Image.Plane plane=image.getPlanes()[0];ByteBuffer b=plane.getBuffer();
        int ps=plane.getPixelStride(),rs=plane.getRowStride(),limit=b.limit();
        int gx=18,gy=5;StringBuilder signature=new StringBuilder("TOPLEFT:");
        for(int cy=0;cy<gy;cy++)for(int cx=0;cx<gx;cx++){
            int count=0,bright=0;
            int xl=from+(to-from)*cx/gx,xr=from+(to-from)*(cx+1)/gx;
            int yt=y0+(y1-y0)*cy/gy,yb=y0+(y1-y0)*(cy+1)/gy;
            for(int y=yt;y<yb;y+=2)for(int x=xl;x<xr;x+=2){
                int pos=y*rs+x*ps;if(pos+2>=limit)continue;
                int r=b.get(pos)&255,g=b.get(pos+1)&255,bl=b.get(pos+2)&255;
                count++;
                if(Math.max(r,Math.max(g,bl))>92 && (r+g+bl)>125)bright++;
            }
            int level=count==0?0:Math.min(3,(bright*6)/count);
            signature.append((char)('0'+level));
        }
        return signature.toString();
    }

    public void close(){recognizer.close();}
}
