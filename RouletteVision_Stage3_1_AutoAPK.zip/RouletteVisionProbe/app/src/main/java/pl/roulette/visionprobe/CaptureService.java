package pl.roulette.visionprobe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Read-only foreground capture with explicit Android consent and local OCR. */
public class CaptureService extends Service {
    public static final String ACTION_START="pl.roulette.visionprobe.START",ACTION_STOP="pl.roulette.visionprobe.STOP";
    public static final String EXTRA_RESULT_CODE="result_code",EXTRA_RESULT_DATA="result_data";
    public static final String PREFS="probe_state",KEY_STATUS="readout";
    private static final String CHANNEL="roulette_vision_capture_v31";
    private static final int NOTICE=1001;
    private HandlerThread captureThread;private Handler handler;
    private MediaProjection projection;private ImageReader reader;private VirtualDisplay virtualDisplay;
    private WindowManager wm;private LinearLayout overlay;private TextView overlayText;
    private final FrameAnalyzer movement=new FrameAnalyzer();
    private PredictionEngine engine;private ResultOcr ocr;
    private int captureWidth,captureHeight;private long lastDisplayCheck,totalFrames,lastReport,frames;
    private boolean resizing,session;
    private double movementTotal;
    private String lastOcr="OCR: czekam na wyróżniony wynik u góry";
    private String candidateSignature="",lastAccepted="";
    private int candidateNumber=-1,stable=0;
    private final MediaProjection.Callback callback=new MediaProjection.Callback(){@Override public void onStop(){saveStatus("Przechwytywanie zakończone.");stopSelf();}};
    @Override public void onCreate(){super.onCreate();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
            new NotificationChannel(CHANNEL,"Roulette Vision — OCR",NotificationManager.IMPORTANCE_LOW));
        captureThread=new HandlerThread("roulette-ocr-capture");captureThread.start();handler=new Handler(captureThread.getLooper());
        engine=new PredictionEngine(this);
        lastAccepted=getSharedPreferences(PREFS,MODE_PRIVATE).getString("last_ocr_signature","");
        ocr=new ResultOcr(new ResultOcr.Listener(){
            @Override public void onRead(int number,String signature,String diagnostic){
                // A stable strip containing the highlighted number AND its neighbours is required.
                if(!signature.equals(candidateSignature)||number!=candidateNumber){candidateSignature=signature;candidateNumber=number;stable=1;}
                else stable++;
                lastOcr=diagnostic+" (stabilność "+Math.min(stable,3)+"/3)";
                if(stable>=3&&!signature.equals(lastAccepted)){
                    // Reload model in case a manual correction was made in the UI.
                    engine=new PredictionEngine(CaptureService.this);
                    if(engine.record(number,"OCR z Coldbet")){
                        lastAccepted=signature;
                        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("last_ocr_signature",signature).apply();
                        lastOcr="ZAPISANO "+number+" · pasek: "+signature;
                    }
                }
            }
            @Override public void onUncertain(String diagnostic){lastOcr="BRAK PEWNOŚCI: "+diagnostic;candidateSignature="";stable=0;}
        });
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(intent.getAction())){saveStatus("Zatrzymano.");stopSelf();return START_NOT_STICKY;}
        if(!ACTION_START.equals(intent.getAction()))return START_NOT_STICKY;
        try{
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q)startForeground(NOTICE,notification("Rozpoczynanie analizy…"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(NOTICE,notification("Rozpoczynanie analizy…"));
            Intent consent=Build.VERSION.SDK_INT>=33?intent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class):intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if(consent==null)throw new IllegalStateException("Brak zgody na ekran");
            if(session)stopFrames();
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(intent.getIntExtra(EXTRA_RESULT_CODE,-1),consent);
            if(projection==null)throw new IllegalStateException("MediaProjection=null");
            projection.registerCallback(callback,handler);startFrames();installOverlay();session=true;
            saveStatus("Przechwytywanie rozpoczęte. Otwórz Coldbet i obserwuj pasek zwycięskich numerów.");
        }catch(Exception e){saveStatus("Błąd startu: "+e.getClass().getSimpleName()+": "+e.getMessage());stopSelf();}
        return START_NOT_STICKY;
    }
    private DisplayMetrics metrics(){DisplayMetrics m=new DisplayMetrics();((WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);return m;}
    private int[] wantedSize(DisplayMetrics m){double sc=Math.min(1,1440.0/Math.max(m.widthPixels,m.heightPixels));return new int[]{Math.max(2,(int)(m.widthPixels*sc)),Math.max(2,(int)(m.heightPixels*sc))};}
    private void startFrames(){DisplayMetrics m=metrics();int[] s=wantedSize(m);captureWidth=s[0];captureHeight=s[1];
        reader=ImageReader.newInstance(captureWidth,captureHeight,PixelFormat.RGBA_8888,3);
        reader.setOnImageAvailableListener(this::receiveFrame,handler);
        virtualDisplay=projection.createVirtualDisplay("Roulette Vision PRO 3.1",captureWidth,captureHeight,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        lastReport=SystemClock.elapsedRealtime();
    }
    private void checkResize(){
        long now=SystemClock.elapsedRealtime();if(resizing||now-lastDisplayCheck<900)return;lastDisplayCheck=now;
        DisplayMetrics m=metrics();int[] s=wantedSize(m);if(Math.abs(s[0]-captureWidth)<3&&Math.abs(s[1]-captureHeight)<3)return;
        resizing=true;
        handler.post(()->{try{
            if(virtualDisplay==null||reader==null)return;
            ImageReader old=reader;ImageReader fresh=ImageReader.newInstance(s[0],s[1],PixelFormat.RGBA_8888,3);
            old.setOnImageAvailableListener(null,null);
            virtualDisplay.resize(s[0],s[1],m.densityDpi);
            virtualDisplay.setSurface(fresh.getSurface());reader=fresh;captureWidth=s[0];captureHeight=s[1];
            fresh.setOnImageAvailableListener(this::receiveFrame,handler);old.close();
            saveStatus("Dopasowano ekran "+s[0]+"×"+s[1]);
        }catch(Exception e){saveStatus("Błąd orientacji: "+e.getMessage());}finally{resizing=false;}});
    }
    private void receiveFrame(ImageReader source){Image image=null;
        try{
            image=source.acquireLatestImage();if(image==null)return;
            checkResize();FrameAnalyzer.Reading reading=movement.analyze(image);movementTotal+=reading.changePercent;
            frames++;totalFrames++;
            // OCR consumes an independent bitmap copy; do not retain Image past this callback.
            if(ocr!=null)ocr.capture(image);
            long now=SystemClock.elapsedRealtime();
            if(now-lastReport>=1400){
                double seconds=(now-lastReport)/1000.0,fps=frames/seconds,delta=movementTotal/Math.max(1,frames);
                engine=new PredictionEngine(this);
                String diagnostics=String.format(Locale.forLanguageTag("pl-PL"),"Klatki/s %.1f · Zmiana %.1f%% · klatki %d",fps,delta,totalFrames);
                saveStatus(diagnostics+"\n"+lastOcr+"\n\n"+engine.summary());
                if(overlayText!=null){String label=engine.overlay()+"\n"+lastOcr;
                    overlayText.post(()->{if(overlayText!=null)overlayText.setText(label);});}
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE,notification("Rozpoznawanie wyników · "+Math.round(fps)+" FPS"));
                frames=0;movementTotal=0;lastReport=now;
            }
        }catch(Exception ex){saveStatus("Błąd przechwytywania: "+ex.getMessage());}
        finally{if(image!=null)image.close();}
    }
    private Notification notification(String txt){Intent stop=new Intent(this,CaptureService.class);stop.setAction(ACTION_STOP);
        PendingIntent pending=PendingIntent.getService(this,0,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Roulette Vision PRO 3.1")
            .setContentText(txt).setOngoing(true).setOnlyAlertOnce(true).addAction(android.R.drawable.ic_media_pause,"Zatrzymaj",pending).build();
    }
    private void installOverlay(){if(!Settings.canDrawOverlays(this))return;
        try{wm=(WindowManager)getSystemService(WINDOW_SERVICE);overlay=new LinearLayout(this);overlay.setOrientation(LinearLayout.VERTICAL);
            overlay.setPadding(dp(9),dp(7),dp(9),dp(7));
            android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(0xE918293E);bg.setStroke(dp(1),0xFF3A92B8);bg.setCornerRadius(dp(10));overlay.setBackground(bg);
            overlayText=new TextView(this);overlayText.setTextColor(Color.WHITE);overlayText.setTextSize(10);overlayText.setTypeface(Typeface.MONOSPACE);
            overlayText.setText("ROULETTE VISION 3.1\nOczekiwanie na numer...");overlay.addView(overlayText);
            WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(255),WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
            p.gravity=Gravity.BOTTOM|Gravity.START;p.x=dp(8);p.y=dp(42);wm.addView(overlay,p);
        }catch(Exception e){saveStatus("Brak nakładki: "+e.getMessage());overlay=null;overlayText=null;}
    }
    private void saveStatus(String s){getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_STATUS,s).apply();}
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void stopFrames(){session=false;
        if(reader!=null){try{reader.setOnImageAvailableListener(null,null);}catch(Exception ignored){}}
        if(virtualDisplay!=null){virtualDisplay.release();virtualDisplay=null;}
        if(reader!=null){reader.close();reader=null;}
        if(projection!=null){MediaProjection p=projection;projection=null;try{p.unregisterCallback(callback);}catch(Exception ignored){}try{p.stop();}catch(Exception ignored){}}
    }
    @Override public void onDestroy(){stopFrames();if(wm!=null&&overlay!=null){try{wm.removeView(overlay);}catch(Exception ignored){}}
        overlay=null;overlayText=null;if(ocr!=null){ocr.close();ocr=null;}if(captureThread!=null)captureThread.quitSafely();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
