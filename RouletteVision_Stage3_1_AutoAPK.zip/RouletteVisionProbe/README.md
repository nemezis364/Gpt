# Roulette Vision PRO 3.1 — górny lewy wynik

Projekt Android (Java/Gradle). Kontynuacja działającego APK PRO 3.0, ale z przebudowanym odczytem ostatniego numeru.

## Co się zmieniło

- OCR nie szuka już wyniku w środku górnego paska.
- Detektor szuka **wyróżnionego, wypełnionego pola wyniku**: po lewej w trybie pionowym Coldbet; w środkowej części górnego paska w trybie poziomym.
- Rozpoznawanie obsługuje czerwone, zielone i szare pole dla różnych kolorów numerów.
- Odczytywany jest **tylko numer z wyróżnionego pola**, z drugim podejściem OCR do jego obszaru w szerszym pasku.
- Nie jest już wymagane rozpoznanie drewnianego koła, ponieważ użytkownik korzysta również z Immersive Roulette z inną oprawą graficzną.
- Program wymaga trzech stabilnych odczytów i monitoruje zmiany sąsiednich liczb historycznych; ogranicza to wielokrotne zapisywanie tego samego wyniku.
- W nakładce / statusie pojawia się m.in. `GÓRNY PASEK: 1` i pozycja wykrytego pola.

## Co zostało bez zmian

- TOP 1 na podstawie 4 ostatnich odległości, w kierunku CCW;
- historyczne sektory 3×5 (15 różnych kieszeni);
- próg 3/6 dla wyświetlania sektorów;
- wskazania tuzinów i parzystych/nieparzystych;
- nakładka nad Coldbet, profil stołu, import JSON, ręczna korekta.

## Ważne ograniczenia

Odczyt OCR to prototyp. Mimo testów wykrywania wyróżnionego pola na czterech wcześniejszych zrzutach ekranu, nie został on jeszcze przetestowany na żywej transmisji z urządzenia użytkownika. Przy niepewnym odczycie aplikacja ma pozostać bez automatycznego zapisu; porównuj odczyt z rzeczywistym numerem i w razie potrzeby koryguj ręcznie. Aplikacja nie stawia zakładów, nie omija zabezpieczeń ekranu ani nie dowodzi przewagi nad kasynem.

## Zbudowanie APK z GitHub Actions

1. Wgraj `RouletteVision_Stage3_1_AutoAPK.zip` do repozytorium `nemezis364/Gpt` na głównej gałęzi.
2. W `.github/workflows/build-apk.yml` ustaw:

   `run: unzip -q RouletteVision_Stage3_1_AutoAPK.zip`

3. Zapisz (`Commit changes`), otwórz `Actions` i pobierz artefakt `RouletteVision-APK` po udanej kompilacji.
4. Z ZIP artefaktu wypakuj `app-debug.apk` i zainstaluj go na telefonie.

Zachowanie tego samego identyfikatora pakietu `pl.roulette.visionprobe` umożliwia zwykłą aktualizację, o ile podpis debug jest zgodny. Jeśli Android zgłosi konflikt podpisów, eksportuj potrzebne dane przed odinstalowaniem starszej aplikacji.
