# Aktualizacja Roulette Vision - etap 2

Repo: https://github.com/nemezis364/Gpt

1. Wgraj do katalogu głównego repo plik RouletteVision_Stage2_AutoAPK.zip (nierozpakowany), zatwierdź Commit changes.
2. Otwórz .github/workflows/build-apk.yml (istniejący plik) i zmień jedną linię:
   run: unzip -q RouletteVision_GitHub_AutoAPK.zip
   na:
   run: unzip -q RouletteVision_Stage2_AutoAPK.zip
3. Zatwierdź Commit changes.
4. W Actions -> najnowsza kompilacja -> Artifacts pobierz RouletteVision-APK.
5. Jeśli Android nie pozwala aktualizować poprzedniego testu ze względu na inny podpis debug, odinstaluj wcześniejszą aplikację Roulette Vision (usuwa tylko dane prototypu), potem zainstaluj nowe APK. Przed odinstalowaniem upewnij się, że nie potrzebujesz danych aplikacji.

To eksperymentalna diagnostyka jasnego punktu i zielonej kieszeni, a nie działający predyktor ruletki.
