package pl.roulette.visionprobe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;

/** Foreground screen-share service. Never uploads, records, or exports captured frames. */
public class CaptureService extends Service {
    public static final String ACTION_START = "pl.roulette.visionprobe.START";
    public static final String ACTION_STOP = "pl.roulette.visionprobe.STOP";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String PREFS = "probe_state";
    public static final String KEY_STATUS = "readout";
    private static final String CHANNEL = "vision_capture_test";
    private static final int NOTIFICATION_ID = 1001;
    private final FrameAnalyzer analyzer = new FrameAnalyzer();
    private final WheelVisionAnalyzer wheelAnalyzer = new WheelVisionAnalyzer();
    private WheelVisionAnalyzer.Reading wheelReading;
    private long lastWheelAnalysis;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay virtualDisplay;
    private WindowManager windowManager;
    private TextView overlayText;
    private LinearLayout overlay;
    private long totalFrames;
    private long framesSinceStatus;
    private long lastStatusTime;
    private double accumulatedMovement;
    private double accumulatedBrightness;
    private double accumulatedDark;
    private boolean sessionRunning;
    private int captureWidth, captureHeight;
    private long lastDisplayCheckMs;
    private boolean resizePending;

    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            saveStatus("Przechwytywanie zakończone przez Androida lub użytkownika.");
            stopSelf();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,
                "Roulette Vision — analiza obrazu", NotificationManager.IMPORTANCE_LOW));
        captureThread = new HandlerThread("vision-image-analyzer");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) {
            saveStatus("Sesja zatrzymana. Możesz ją ponownie uruchomić.");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;

        // The FGS must be active before getMediaProjection() on modern Android.
        try {
            Notification startNotification = notification("Uruchamianie przechwytywania…");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, startNotification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, startNotification);
            }
            Intent consentData;
            if (Build.VERSION.SDK_INT >= 33) {
                consentData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            } else {
                consentData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }
            if (consentData == null) throw new IllegalStateException("Brak zgody systemowej.");
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (sessionRunning) stopCaptureOnly();
            projection = manager.getMediaProjection(
                    intent.getIntExtra(EXTRA_RESULT_CODE, -1), consentData);
            if (projection == null) throw new IllegalStateException("Brak projekcji systemowej.");
            projection.registerCallback(projectionCallback, captureHandler);
            startFrames();
            installOverlayIfAllowed();
            sessionRunning = true;
            saveStatus("Przechwytywanie rozpoczęte. Otwórz Auto Roulette w Coldbet.");
        } catch (Exception ex) {
            saveStatus("Błąd uruchomienia: " + ex.getClass().getSimpleName()
                    + " — " + ex.getMessage());
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startFrames() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(metrics);
        // Smaller capture buffer reduces memory and CPU use during first test.
        int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
        double scale = Math.min(1.0, 960.0 / Math.max(1, longSide));
        int width = Math.max(2, (int) Math.round(metrics.widthPixels * scale));
        int height = Math.max(2, (int) Math.round(metrics.heightPixels * scale));
        captureWidth = width;
        captureHeight = height;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(this::receiveFrame, captureHandler);
        virtualDisplay = projection.createVirtualDisplay(
                "Roulette Vision Stage 2.1", width, height, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, captureHandler);
        lastStatusTime = SystemClock.elapsedRealtime();
    }

    /**
     * MediaProjection begins while the app is in portrait. Coldbet rotates to landscape.
     * An ImageReader created for portrait can otherwise receive a letterboxed landscape
     * image, which makes the wheel fail the region-size threshold.
     *
     * Android 14+ allows only one createVirtualDisplay() per projection token. To keep
     * the same MediaProjection session we resize the existing VirtualDisplay and replace
     * its output surface instead of creating a second VirtualDisplay.
     */
    private void scheduleResizeForOrientationIfNeeded() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastDisplayCheckMs < 800 || resizePending) return;
        lastDisplayCheckMs = now;
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(metrics);
        int longSide = Math.max(metrics.widthPixels, metrics.heightPixels);
        double scale = Math.min(1.0, 960.0 / Math.max(1, longSide));
        int newWidth = Math.max(2, (int) Math.round(metrics.widthPixels * scale));
        int newHeight = Math.max(2, (int) Math.round(metrics.heightPixels * scale));
        if (Math.abs(newWidth - captureWidth) < 3 && Math.abs(newHeight - captureHeight) < 3) return;
        resizePending = true;
        captureHandler.post(() -> {
            try {
                if (virtualDisplay == null || reader == null) return;
                ImageReader oldReader = reader;
                ImageReader newReader = ImageReader.newInstance(newWidth, newHeight,
                        PixelFormat.RGBA_8888, 3);
                oldReader.setOnImageAvailableListener(null, null);
                virtualDisplay.resize(newWidth, newHeight, metrics.densityDpi);
                virtualDisplay.setSurface(newReader.getSurface());
                reader = newReader;
                captureWidth = newWidth;
                captureHeight = newHeight;
                newReader.setOnImageAvailableListener(this::receiveFrame, captureHandler);
                oldReader.close();
                // Analyzer automatically resets sampling and tracking for the new size.
                wheelReading = null;
                saveStatus("Zmieniono rozmiar przechwytywania na " + newWidth + "×" + newHeight
                        + ". Szukanie koła w nowej orientacji.");
            } catch (Exception ex) {
                saveStatus("Błąd zmiany orientacji: " + ex.getMessage());
            } finally {
                resizePending = false;
            }
        });
    }

    private void receiveFrame(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null) return;
            scheduleResizeForOrientationIfNeeded();
            FrameAnalyzer.Reading reading = analyzer.analyze(image);
            long frameNs = SystemClock.elapsedRealtimeNanos();
            if (frameNs - lastWheelAnalysis > 100_000_000L) {
                wheelReading = wheelAnalyzer.analyze(image, frameNs);
                lastWheelAnalysis = frameNs;
            }
            totalFrames++;
            framesSinceStatus++;
            accumulatedMovement += reading.changePercent;
            accumulatedBrightness += reading.meanBrightness;
            accumulatedDark += reading.darkPercent;
            long now = SystemClock.elapsedRealtime();
            if (now - lastStatusTime >= 1300) {
                double seconds = (now - lastStatusTime) / 1000.0;
                double fps = framesSinceStatus / seconds;
                double movement = accumulatedMovement / Math.max(1, framesSinceStatus);
                double brightness = accumulatedBrightness / Math.max(1, framesSinceStatus);
                double darkness = accumulatedDark / Math.max(1, framesSinceStatus);
                String verdict = darkness > 97 && brightness < 8
                        ? "PRAWIE CZARNY OBRAZ (możliwa ochrona transmisji)"
                        : movement < 0.35
                        ? "MAŁO RUCHU — sprawdź, czy gra trwa"
                        : "OBRAZ SIĘ ZMIENIA";
                String text = String.format(Locale.forLanguageTag("pl-PL"),
                        "Klatki/s: %.1f  |  Zmiana: %.1f%%\n" +
                        "Jasność: %.0f/255  |  Ciemne: %.0f%%\n" +
                        "%s\nPrzetworzone klatki: %d",
                        fps, movement, brightness, darkness, verdict, totalFrames);
                text += "\n\nETAP 2 — OBSERWACJE PRÓBNE\n" +
                        (wheelReading != null ? wheelReading.overlayText() : "Szukanie koła...");
                saveStatus(text);
                updateOverlay(text);
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(NOTIFICATION_ID, notification(String.format(Locale.US,
                        "%.1f kl./s | ruch %.1f%%", fps, movement)));
                lastStatusTime = now;
                framesSinceStatus = 0;
                accumulatedMovement = 0;
                accumulatedBrightness = 0;
                accumulatedDark = 0;
            }
        } catch (Exception ex) {
            saveStatus("Błąd przetwarzania klatki: " + ex.getMessage());
        } finally {
            if (image != null) image.close();
        }
    }

    private Notification notification(String message) {
        Intent stopIntent = new Intent(this, CaptureService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Roulette Vision — etap 2.1")
                .setContentText(message)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Zatrzymaj", stop)
                .build();
    }

    private void installOverlayIfAllowed() {
        if (!Settings.canDrawOverlays(this)) return;
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            overlay = new LinearLayout(this);
            overlay.setOrientation(LinearLayout.VERTICAL);
            overlay.setPadding(dp(10), dp(7), dp(10), dp(7));
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(0xE916263C);
            bg.setCornerRadius(dp(12));
            bg.setStroke(dp(1), 0xFF40A7E0);
            overlay.setBackground(bg);
            overlayText = new TextView(this);
            overlayText.setText("ROULETTE VISION\nUruchamianie…");
            overlayText.setTextSize(10);
            overlayText.setTextColor(Color.WHITE);
            overlayText.setTypeface(Typeface.MONOSPACE);
            overlay.addView(overlayText);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    dp(260), WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = dp(8);
            params.y = dp(30);
            windowManager.addView(overlay, params);
        } catch (Exception ex) {
            saveStatus("Przechwytywanie działa, ale okno diagnostyczne jest niedostępne: "
                    + ex.getMessage());
            overlay = null;
            overlayText = null;
        }
    }

    private void updateOverlay(String value) {
        if (overlayText != null) {
            String firstLine = value.contains("\n") ? value.substring(0, value.indexOf("\n")) : value;
            String concise = "ROULETTE VISION — ETAP 2.1\n" + firstLine + "\n" +
                    "Bufor: " + captureWidth + "×" + captureHeight + "\n" +
                    (wheelReading != null ? wheelReading.overlayText() : "Szukanie koła...");
            overlayText.post(() -> {
                if (overlayText != null) overlayText.setText(concise);
            });
        }
    }

    private void saveStatus(String text) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATUS, text).apply();
    }

    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    private void stopCaptureOnly() {
        sessionRunning = false;
        if (reader != null) {
            try { reader.setOnImageAvailableListener(null, null); } catch (Exception ignored) { }
        }
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (reader != null) {
            reader.close();
            reader = null;
        }
        captureWidth = captureHeight = 0;
        resizePending = false;
        if (projection != null) {
            MediaProjection old = projection;
            projection = null;
            try { old.unregisterCallback(projectionCallback); } catch (Exception ignored) { }
            try { old.stop(); } catch (Exception ignored) { }
        }
    }

    @Override public void onDestroy() {
        stopCaptureOnly();
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) { }
        }
        overlayText = null;
        overlay = null;
        if (captureThread != null) captureThread.quitSafely();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
