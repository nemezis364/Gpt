# Roulette Vision — etap 2.1

Poprawka przechwytywania obrazu przy zmianie orientacji z pionowej na poziomą
w Coldbet. Android MediaProjection po udzieleniu zgody działa na tym samym tokenie:
rozmiar VirtualDisplay jest zmieniany przez resize/setSurface, bez nowej sesji.

Przywrócono środek okręgu do środka obszaru brązowo-miedzianego (poprzednio
było 75% w pionie i śledzenie wypadało zbyt nisko), zastosowano elastyczny próg
regionu przy pasach letterbox i dodano wyświetlanie wymiarów bufora.

To wersja diagnostyczna. Kandydat jasnego punktu/zera nie jest weryfikacją
śledzenia kulki ani metodą przewidywania wyniku. Nie wykorzystuj do zakładów.

## Budowanie
W GitHub Actions podmień nazwę archiwum w poleceniu unzip na
`RouletteVision_Stage2_1_AutoAPK.zip`; pozostała konfiguracja bez zmian.
