# Roulette Vision Probe — Android / etap 1

**Status:** kod źródłowy działającego założeniowo prototypu do zbudowania w Android Studio. To NIE jest gotowy APK i NIE jest jeszcze algorytm śledzenia kulki ani prognozy sektorów.

## Cel

Na **jednym telefonie z Androidem** sprawdzić, czy system `MediaProjection` potrafi przechwytywać obraz transmisji ruletki z Chrome i przekazywać kolejne klatki do analizy.

Po zgodzie systemowej użytkownik wraca do Chrome. Program automatycznie analizuje klatki w usłudze pierwszoplanowej i pokazuje na nakładce / w powiadomieniu:

- liczbę odbieranych klatek na sekundę,
- procent zmienionych próbek obrazu,
- średnią jasność i odsetek bardzo ciemnych próbek,
- informację, czy obraz jest niemal czarny, statyczny czy się zmienia.

**To są statystyki diagnostyczne**, nie pomiary prędkości kulki. Procent zmiany to nie prawdopodobieństwo trafienia.

## Wymagania

- Android 10 lub nowszy (API 29+), w tym Android 13.
- Android Studio z Android SDK 35, Gradle 8.9 i JDK 17+.
- Internet tylko do pobrania narzędzi kompilacji, nie do działania aplikacji.
- Zgoda systemowa na przechwytywanie obrazu na każdą sesję.
- Opcjonalne uprawnienie do wyświetlania nad innymi aplikacjami.

## Budowanie APK

1. Rozpakuj projekt i otwórz folder `RouletteVisionProbe` w Android Studio.
2. Zsynchronizuj Gradle i pobierz wymagane SDK. Plik `gradle-wrapper.properties` określa wersję Gradle; w archiwum **nie ma** pliku `gradle-wrapper.jar`, więc przy braku lokalnego Gradle może być konieczne jednorazowe wygenerowanie wrappera poleceniem `gradle wrapper --gradle-version 8.9`.
3. Wybierz **Build → Build APK(s)**.
4. APK powinien pojawić się w `app/build/outputs/apk/debug/app-debug.apk`.
5. Zainstaluj go na telefonie po zatwierdzeniu instalacji z wybranego źródła.

## Test na telefonie

1. Uruchom aplikację, opcjonalnie zezwól na „Wyświetlanie nad innymi aplikacjami”.
2. Naciśnij `Rozpocznij test ekranu`, a gdy Android zapyta, wybierz **Cały ekran**. Na Androidzie 14+ opcja udostępnienia tylko jednej aplikacji może nie pasować do tego testu.
3. Przejdź do Chrome i otwórz Auto Roulette.
4. Obserwuj nakładkę `ROULETTE VISION — TEST`. Powinna podawać `Klatki/s` i `Zmiana`.
5. Jeżeli klatki napływają, ale gra jest czarna, transmisja może stosować zabezpieczenia. **Nie próbujemy ich obchodzić.**
6. Po 1–2 minutach zatrzymaj przechwytywanie z powiadomienia Androida lub aplikacji.

## Ograniczenia i prywatność

- Brak sieci: aplikacja nie wymaga `INTERNET` i nie posiada modułu wysyłania klatek.
- Brak nagrywania: przechowywane są tylko statystyki diagnostyczne, nie obraz ani film.
- Nie przechwytywać haseł, bankowości ani prywatnych wiadomości; najlepiej uruchomić test tylko podczas transmisji.
- `FLAG_SECURE` i inne mechanizmy DRM mogą uniemożliwić przechwycenie zawartości transmisji. Ciemny obraz nie jest jednoznacznym dowodem zabezpieczenia.
- Na Androidzie 14+ zgoda dotyczy jednej sesji przechwytywania. Każde następne uruchomienie wymaga ponownego potwierdzenia.
- Android może zakończyć sesję przy blokadzie ekranu lub zmianie ustawień.
- Nie było możliwości **skompilowania i uruchomienia projektu na telefonie** w środowisku jego przygotowania — wymagana jest weryfikacja na urządzeniu.

## Kolejne etapy po udanym teście

1. Automatyczna lokalizacja koła i kalibracja perspektywy na klatkach.
2. Śledzenie pozycji kulki i znacznika zera w czasie.
3. Estymacja prędkości kątowej i opóźnienia transmisji.
4. Prognoza trzech niepokrywających się sektorów 5-kieszeniowych i testowanie *na nieznanych wynikach*.

## Dokumentacja Android

- https://developer.android.com/media/grow/media-projection
- https://developer.android.com/security/fraud-prevention/activities
