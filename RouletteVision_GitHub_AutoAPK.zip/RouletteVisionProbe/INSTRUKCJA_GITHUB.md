# Roulette Vision — automatyczna kompilacja APK na GitHub

Projekt jest prototypem diagnostycznym, nie gotowym programem do przewidywania wyniku ruletki.

1. Utwórz nowe repozytorium na GitHub o nazwie `RouletteVisionProbe` (najlepiej **Private**).
2. Prześlij do niego **zawartość folderu** `RouletteVisionProbe`, zachowując podfolder `.github/workflows`.
3. W repozytorium przejdź do **Actions** i wybierz `Buduj APK Roulette Vision`.
4. Jeśli workflow jeszcze nie wystartował, kliknij **Run workflow**.
5. Po udanej kompilacji przejdź do podsumowania uruchomienia. W sekcji **Artifacts** pobierz `RouletteVision-APK` (jest to ZIP z APK).
6. Rozpakuj ZIP na telefonie i zainstaluj plik `app-debug.apk`.

Na Androidzie trzeba potwierdzić instalację ze źródła, z którego otwierasz APK. Nie instaluj aplikacji z nieznanych źródeł. Zawsze upewnij się, że APK pochodzi z Twojego workflow.

Automatyczna kompilacja potrzebuje dostępu GitHub Actions do internetu, aby pobrać Android SDK i Gradle. Żadne klatki z ekranu nie są wysyłane do GitHub — GitHub służy wyłącznie do kompilacji kodu źródłowego.
