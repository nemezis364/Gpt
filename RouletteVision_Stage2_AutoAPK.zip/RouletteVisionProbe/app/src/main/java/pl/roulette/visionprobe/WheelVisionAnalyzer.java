package pl.roulette.visionprobe;

import android.media.Image;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Locale;

/**
 * Stage 2: experimental local, unsupervised wheel region / moving bright point / green patch
 * detection. Screen-coordinate estimates are NOT confirmed ball / zero detections.
 * No image is recorded or sent anywhere.
 */
public final class WheelVisionAnalyzer {
    private static final int GRID_STEP = 4;
    private static final int BINS = 72;
    private int[] previousLuma;
    private int gridW, gridH;
    private double centerX = -1, centerY = -1, radiusX, radiusY;
    private int regionSamples;
    private int missedRegionFrames;
    private double previousBrightAngle = Double.NaN, previousGreenAngle = Double.NaN;
    private long brightTimeNs, greenTimeNs;
    private double brightRps, greenRps;
    private int brightContinuity, greenContinuity;

    public static final class Reading {
        public final boolean regionFound;
        public final double x, y, zoneMovementPercent, centerConfidence;
        public final boolean brightCandidate, greenCandidate;
        public final boolean brightMotionConfirmed, greenMotionConfirmed;
        public final double brightAngle, greenAngle, brightRps, greenRps;
        Reading(boolean found, double x, double y, double moved, double confidence,
                boolean bright, boolean green, boolean brightConfirmed, boolean greenConfirmed,
                double brightAngle, double greenAngle, double brightRps, double greenRps) {
            this.regionFound = found;
            this.x = x; this.y = y;
            this.zoneMovementPercent = moved; this.centerConfidence = confidence;
            this.brightCandidate = bright; this.greenCandidate = green;
            this.brightMotionConfirmed = brightConfirmed; this.greenMotionConfirmed = greenConfirmed;
            this.brightAngle = brightAngle; this.greenAngle = greenAngle;
            this.brightRps = brightRps; this.greenRps = greenRps;
        }
        public String overlayText() {
            if (!regionFound) return "Koło: szukanie kolorowego obszaru\n" +
                    "Otwórz ruletkę na pełnym ekranie.";
            String base = String.format(Locale.forLanguageTag("pl-PL"),
                    "Strefa koła: %d%% X, %d%% Y (przybliżona)\n" +
                    "Ruch w strefie: %.1f%%\n", (int) Math.round(x * 100),
                    (int) Math.round(y * 100), zoneMovementPercent);
            String ball = brightMotionConfirmed
                    ? String.format(Locale.forLanguageTag("pl-PL"),
                    "Jasny punkt: ruch %.2f obr/s (TEST)\n", Math.abs(brightRps))
                    : brightCandidate ? "Jasny punkt: kandydat — brak potwierdzenia\n"
                    : "Jasny punkt/kulka: szukanie\n";
            String green = greenMotionConfirmed
                    ? String.format(Locale.forLanguageTag("pl-PL"),
                    "Zielony punkt: ruch %.2f obr/s (TEST)", Math.abs(greenRps))
                    : greenCandidate ? "Zielony punkt/0: kandydat — niepewny"
                    : "Zielony punkt/0: szukanie";
            return base + ball + green;
        }
    }

    private static double wrap(double degrees) {
        while (degrees > 180) degrees -= 360;
        while (degrees < -180) degrees += 360;
        return degrees;
    }

    public Reading analyze(Image image, long timeNs) {
        if (image.getPlanes().length == 0) return empty();
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer pixels = plane.getBuffer();
        int w = image.getWidth(), h = image.getHeight();
        int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
        if (pixelStride < 3 || w < 160 || h < 120) return empty();
        int gw = (w + GRID_STEP - 1) / GRID_STEP;
        int gh = (h + GRID_STEP - 1) / GRID_STEP;
        if (previousLuma == null || gw != gridW || gh != gridH) {
            previousLuma = new int[gw * gh];
            Arrays.fill(previousLuma, -1);
            gridW = gw; gridH = gh;
            centerX = -1;
            brightContinuity = greenContinuity = 0;
            previousBrightAngle = previousGreenAngle = Double.NaN;
        }
        int copper = 0;
        int[] xCopper = new int[(w + 7) / 8 + 1];
        int[] yCopper = new int[(h + 7) / 8 + 1];
        // Large orange/copper region is a coarse *candidate* for the roulette image.
        for (int y = h / 8; y < (int) (h * 0.97); y += 8) {
            for (int x = w / 8; x < (int) (w * 0.89); x += 8) {
                int p = y * rowStride + x * pixelStride;
                if (p < 0 || p + 2 >= pixels.limit()) continue;
                int r = pixels.get(p) & 255, g = pixels.get(p + 1) & 255;
                int b = pixels.get(p + 2) & 255;
                if (r > 63 && g > 28 && r > g * 1.30 && g > b * 1.12 && r > b * 1.75) {
                    copper++;
                    xCopper[x / 8]++;
                    yCopper[y / 8]++;
                }
            }
        }
        // Trim isolated HUD chips / UI elements that would distort the wheel region.
        int copperMinX = percentileCoordinate(xCopper, copper, 0.02);
        int copperMaxX = percentileCoordinate(xCopper, copper, 0.98);
        int copperMinY = percentileCoordinate(yCopper, copper, 0.02);
        int copperMaxY = percentileCoordinate(yCopper, copper, 0.98);
        double spanX = copperMaxX - copperMinX, spanY = copperMaxY - copperMinY;
        boolean candidate = copper > 90 && spanX > w * .25 && spanY > h * .26;
        if (candidate) {
            double candidateCx = (copperMinX + copperMaxX) * .5;
            double candidateCy = copperMinY + .75 * spanY;
            double candidateRx = spanX * .275;
            double candidateRy = spanY * .48;
            if (centerX < 0) {
                centerX = candidateCx; centerY = candidateCy;
                radiusX = candidateRx; radiusY = candidateRy;
            } else {
                centerX = .85 * centerX + .15 * candidateCx;
                centerY = .85 * centerY + .15 * candidateCy;
                radiusX = .85 * radiusX + .15 * candidateRx;
                radiusY = .85 * radiusY + .15 * candidateRy;
            }
            regionSamples++;
            missedRegionFrames = 0;
        } else if (++missedRegionFrames > 12) {
            centerX = -1;
            regionSamples = 0;
            brightContinuity = greenContinuity = 0;
            previousBrightAngle = previousGreenAngle = Double.NaN;
            return empty();
        }
        if (centerX < 0 || radiusX < 15 || radiusY < 15) return empty();

        int inRegion = 0, moved = 0;
        int[] brightBins = new int[BINS];
        int[] greenBins = new int[BINS];
        int totalBright = 0, totalGreen = 0;
        for (int y = GRID_STEP / 2; y < h; y += GRID_STEP) {
            for (int x = GRID_STEP / 2; x < w; x += GRID_STEP) {
                int p = y * rowStride + x * pixelStride;
                if (p < 0 || p + 2 >= pixels.limit()) continue;
                int r = pixels.get(p) & 255, g = pixels.get(p+1) & 255;
                int b = pixels.get(p+2) & 255;
                int luminance = (54 * r + 183 * g + 19 * b) >> 8;
                int cell = (y / GRID_STEP) * gridW + (x / GRID_STEP);
                int old = previousLuma[cell];
                previousLuma[cell] = luminance;
                double dx = (x - centerX) / radiusX;
                double dy = (y - centerY) / radiusY;
                double radSq = dx*dx + dy*dy;
                // Exclude the center of the betting table, HUD and most of the wooden surround.
                if (radSq < .35 || radSq > 1.85) continue;
                inRegion++;
                boolean changing = old >= 0 && Math.abs(old - luminance) > 20;
                if (changing) moved++;
                if (radSq < .50 || radSq > 1.65) continue;
                double angle = Math.atan2(dy, dx) * 180.0 / Math.PI;
                if (angle < 0) angle += 360;
                int bin = Math.min(BINS-1, (int) (angle * BINS / 360.));
                int max = Math.max(r, Math.max(g, b));
                int min = Math.min(r, Math.min(g, b));
                // Candidates only; bright reflections and white digits can generate false hits.
                if (changing && luminance > 185 && max - min < 58) {
                    brightBins[bin] += 1;
                    totalBright++;
                }
                if (g > 67 && g > r * 1.32 && g > b * 1.20) {
                    greenBins[bin] += 1;
                    totalGreen++;
                }
            }
        }
        double motion = 100. * moved / Math.max(1, inRegion);
        int brightBin = peakBin(brightBins), greenBin = peakBin(greenBins);
        // Ignore lone pixels; require multiple samples in a concentrated angular band.
        boolean brightFound = totalBright >= 3 && brightBin >= 0 && brightBins[brightBin] >= 2 && motion > .18;
        boolean greenFound = totalGreen >= 3 && greenBin >= 0 && greenBins[greenBin] >= 2;
        double brightAngle = (brightBin + .5) * 360. / BINS;
        double greenAngle = (greenBin + .5) * 360. / BINS;
        brightContinuity = updateMotion(brightFound, brightAngle, timeNs, true);
        greenContinuity = updateMotion(greenFound, greenAngle, timeNs, false);
        return new Reading(true, centerX / w, centerY / h, motion,
                Math.min(1., copper / 800.0), brightFound, greenFound,
                brightContinuity >= 3 && Math.abs(brightRps) > .05,
                greenContinuity >= 3 && Math.abs(greenRps) > .02,
                brightAngle, greenAngle, brightRps, greenRps);
    }

    private int updateMotion(boolean found, double angle, long now, boolean bright) {
        double oldAngle = bright ? previousBrightAngle : previousGreenAngle;
        long oldTime = bright ? brightTimeNs : greenTimeNs;
        int continuity = bright ? brightContinuity : greenContinuity;
        if (found) {
            if (!Double.isNaN(oldAngle) && oldTime > 0) {
                double seconds = (now - oldTime) / 1e9;
                double delta = wrap(angle - oldAngle);
                if (seconds > .045 && seconds < .55 && Math.abs(delta) >= 2.0 && Math.abs(delta) <= 100) {
                    double speed = delta / 360.0 / seconds;
                    double prevSpeed = bright ? brightRps : greenRps;
                    if (continuity > 0 && Math.signum(speed) != Math.signum(prevSpeed)) continuity = 0;
                    continuity++;
                    if (bright) brightRps = speed; else greenRps = speed;
                } else continuity = 0;
            }
            if (bright) { previousBrightAngle = angle; brightTimeNs = now; }
            else { previousGreenAngle = angle; greenTimeNs = now; }
        } else {
            continuity = 0;
            if (bright) previousBrightAngle = Double.NaN;
            else previousGreenAngle = Double.NaN;
        }
        if (bright) brightContinuity = continuity;
        else greenContinuity = continuity;
        return continuity;
    }

    private static int percentileCoordinate(int[] histogram, int n, double proportion) {
        if (n == 0) return 0;
        double target = n * proportion;
        int sum = 0;
        for (int i = 0; i < histogram.length; i++) {
            sum += histogram[i];
            if (sum >= target) return i * 8;
        }
        return (histogram.length - 1) * 8;
    }

    private static int peakBin(int[] bins) {
        int idx = -1, max = 0;
        for (int i = 0; i < bins.length; i++) {
            int smooth = bins[i] + bins[(i + 1) % bins.length] + bins[(i + bins.length - 1) % bins.length];
            if (smooth > max) { max = smooth; idx = i; }
        }
        return idx;
    }

    private static Reading empty() {
        return new Reading(false, 0, 0, 0, 0, false, false, false, false,
                Double.NaN, Double.NaN, 0, 0);
    }
}
