package pl.roulette.visionprobe;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN_CAPTURE = 4101;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private TextView status;
    private TextView overlayStatus;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateStatus();
            uiHandler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(11, 18, 32));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(20));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("🎯 ROULETTE VISION", 25, 0xFFE6F4FF, true);
        root.addView(title);
        root.addView(text("ETAP 2: AUTOMATYCZNA ANALIZA OBRAZU", 12, 0xFF63DBB3, true));
        root.addView(gap(14));
        root.addView(text("Program automatycznie szuka obszaru koła, analizuje ruch i próbuje wykrywać jasny punkt oraz zieloną kieszeń. Są to na razie niepotwierdzone wskazania testowe.", 16, 0xFFC5D5E7, false));
        root.addView(gap(20));

        Button overlayButton = button("1. Włącz małe okno diagnostyczne");
        overlayButton.setOnClickListener(v -> requestOverlay());
        root.addView(overlayButton);
        overlayStatus = text("", 13, 0xFF93A9BE, false);
        root.addView(overlayStatus);
        root.addView(gap(16));

        Button startButton = button("2. Rozpocznij test ekranu");
        startButton.setOnClickListener(v -> requestCapture());
        root.addView(startButton);
        root.addView(gap(7));

        Button stopButton = button("Zatrzymaj przechwytywanie");
        stopButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF913747));
        stopButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, CaptureService.class);
            intent.setAction(CaptureService.ACTION_STOP);
            startService(intent);
            uiHandler.postDelayed(this::updateStatus, 600);
        });
        root.addView(stopButton);
        root.addView(gap(18));

        root.addView(text("STATUS TESTU", 14, 0xFF63DBB3, true));
        status = text("Oczekiwanie na uruchomienie", 17, 0xFFEDF3FB, false);
        status.setPadding(dp(13), dp(15), dp(13), dp(15));
        status.setBackgroundColor(0xFF18263D);
        root.addView(status);
        root.addView(gap(15));
        root.addView(text("Jak testować", 18, 0xFFEDF3FB, true));
        root.addView(text(
            "1. Zezwól na wyświetlanie nad innymi aplikacjami (opcjonalne, ale zalecane).\n" +
            "2. Naciśnij „Rozpocznij test ekranu”.\n" +
            "3. W systemowym oknie wybierz „Cały ekran” i zatwierdź udostępnianie.\n" +
            "4. Otwórz Auto Roulette w aplikacji Coldbet i ustaw widok poziomy.\n" +
            "5. Sprawdź w panelu: STREFA KOŁA, RUCH, JASNY PUNKT i ZIELONY PUNKT.\n" +
            "6. Zatrzymaj test po powrocie do aplikacji.",
            15, 0xFFC5D5E7, false));
        root.addView(gap(18));
        root.addView(text("PRYWATNOŚĆ I OGRANICZENIA", 14, 0xFF63DBB3, true));
        root.addView(text(
            "Obraz jest analizowany tylko w pamięci telefonu. Aplikacja nie wysyła klatek do internetu ani nie nagrywa filmów. " +
            "Na zabezpieczonej transmisji obraz może być czarny. Wykryte jasne i zielone punkty mogą być fałszywymi wskazaniami. Nie ma jeszcze wiarygodnego śledzenia kulki ani prognozowania 3×5. Nie używaj tych wskazań do obstawiania.",
            13, 0xFFA8B9CE, false));
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) { updateStatus(); return; }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void requestCapture() {
        try {
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
        } catch (Exception ex) {
            status.setText("Błąd zgody Androida: " + ex.getMessage());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                status.setText("Anulowano zgodę na przechwytywanie.");
                return;
            }
            Intent serviceIntent = new Intent(this, CaptureService.class);
            serviceIntent.setAction(CaptureService.ACTION_START);
            serviceIntent.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
            serviceIntent.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            status.setText("Uruchamianie sesji. Przejdź do transmisji ruletki.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(ticker);
        uiHandler.post(ticker);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(ticker);
        super.onPause();
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText(getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)
                .getString(CaptureService.KEY_STATUS, "Sesja nieuruchomiona"));
        if (overlayStatus != null) {
            overlayStatus.setText(Settings.canDrawOverlays(this)
                    ? "✓ Uprawnienie do okna diagnostycznego: włączone"
                    : "○ Uprawnienie do okna diagnostycznego: wyłączone");
        }
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setLineSpacing(dp(2), 1.0f);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String value) {
        Button btn = new Button(this);
        btn.setText(value);
        btn.setTextSize(15);
        btn.setTextColor(0xFFFFFFFF);
        btn.setAllCaps(false);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF176DBA));
        return btn;
    }

    private View gap(int height) {
        View view = new View(this);
        view.setLayoutParams(new LinearLayout.LayoutParams(1, dp(height)));
        return view;
    }

    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
}
