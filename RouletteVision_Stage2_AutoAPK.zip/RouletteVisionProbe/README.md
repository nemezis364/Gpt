# Roulette Vision — etap 2: diagnostyka obrazu Coldbet

Aplikacja Android (Java, minSdk 29) z przechwytywaniem ekranu po systemowej zgodzie użytkownika.

## Co robi

- Utrzymuje dotychczasowe przechwytywanie ekranu i nakładkę nad innymi aplikacjami.
- Analizuje klatki lokalnie, bez sieci, nagrań ani wysyłania obrazu.
- Ocenia orientacyjny obszar koła na podstawie dużej plamy miedziano-pomarańczowych pikseli.
- Liczy zmiany jasności **wewnątrz tego obszaru**, zamiast wyłącznie na całym ekranie.
- Szuka poruszających się jasnych punktów oraz zielonych obszarów, szacuje prędkość kątową wyłącznie przy kilku zgodnych pomiarach.

## Ograniczenia

**To eksperymentalny wykrywacz kandydatów, nie sprawdzony tracker kulki ani zera.** Białe cyfry, odblaski, zielone elementy interfejsu mogą dawać błędne wskazania. Szacunki prędkości nie są zweryfikowane. Nie prognozuje liczb, nie wskazuje sektorów i nie obstawia automatycznie.

Działa najpewniej z widokiem Coldbet Auto Roulette w poziomie podobnym do testowego. Po zmianie kadru lokalizacja może być nietrafna. Jeśli pojawiają się inne aplikacje/zabezpieczona transmisja, nie obchodzimy zabezpieczeń.

## Kompilacja

W dotychczasowym GitHub Actions, po rozpakowaniu ZIP: `gradle --no-daemon :app:assembleDebug` wewnątrz folderu `RouletteVisionProbe`.

APK z `app/build/outputs/apk/debug/app-debug.apk` jest diagnostyczną wersją debug.

## Test

1. Zainstaluj aktualizację nad poprzednią aplikacją (ten sam `applicationId`).
2. Włącz nakładkę oraz przechwytywanie całego ekranu.
3. W Coldbet otwórz Auto Roulette, najchętniej z kołem widocznym przez kilkanaście obrotów.
4. Zrób zrzut panelu etapu 2. Zwróć uwagę, czy wskazania jasnego i zielonego punktu są stabilne tylko podczas ruchu.

## Prywatność

Nie ma pozwolenia `INTERNET`. Klatki są analizowane w pamięci, bez zapisu filmów i obrazów. Nie używaj przechwytywania podczas przeglądania wrażliwych danych.
