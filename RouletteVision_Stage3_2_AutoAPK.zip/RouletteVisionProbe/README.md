# Roulette Vision PRO 3.2 — OCR 6/9/0 i ostatnie trafienie 3×5

Projekt Android (Java/Gradle), następca PRO 3.1. Zachowuje ten sam identyfikator pakietu i zapisane dane.

## Zmiany

- Odczyt ostatniego numeru wyłącznie z wyróżnionego pola górnego paska Coldbet.
- **Zero**: gdy wyróżnione pole jest zielone, numer 0 jest rozpoznawany bez OCR (w europejskiej ruletce jedyne zielone pole oznacza 0). Rozpoznawanie zieleni uwzględnia ciemniejsze odcienie.
- **6/9**: oprócz OCR stosowana jest lokalna analiza kształtu cyfry. Dziurka w 6 jest niżej, w 9 wyżej. Jeżeli nie da się wiarygodnie odróżnić cyfr, wynik NIE jest automatycznie zapisany. Dla 16/19, 26/29 oraz 36 sprawdzana jest cyfra jedności.
- **Widoczność sektorów 3×5**: zamiast minimum 3/6 liczy się WYŁĄCZNIE ostatnia rozliczona prognoza sektorowa tego profilu. Po TRAFIONEJ — pokazuj następną; po NIETRAFIONEJ — ukryj następną. Ukryte prognozy też są rozliczane w tle i mogą odblokować kolejną prognozę po trafieniu.
- Przed pierwszą rozliczoną prognozą sektory są ukryte. Licznik ostatnich 6 trafień pozostaje informacyjny, lecz nie jest progiem.
- TOP 1 CCW z 4 ostatnich odległości, dobór trzech sektorów po 5 różnych kieszeni, tuziny, parzyste/nieparzyste, profile krupierów, nakładka, ręczna korekta i import JSON pozostają.

## Ograniczenia

Moduł OCR pozostaje eksperymentalny. Zapis wyniku zależy od widoczności i odczytywalności wyróżnionego pola Coldbet. Niepoprawny odczyt zmienia statystyki, dlatego porównuj wyniki z transmisją i używaj ręcznej korekty. Aplikacja nie omija zabezpieczeń ekranu, nie obstawia automatycznie ani nie gwarantuje przewagi nad ruletką. 15 odrębnych numerów daje 15/37 (40,54%) szansy trafienia w uczciwej ruletce europejskiej.

## GitHub Actions — budowa APK

1. Wgraj `RouletteVision_Stage3_2_AutoAPK.zip` do repozytorium `nemezis364/Gpt` na gałąź `main`.
2. W `.github/workflows/build-apk.yml` ustaw linię `run: unzip -q RouletteVision_Stage3_2_AutoAPK.zip`.
3. Zapisz (`Commit changes`), otwórz zakładkę `Actions`, po zakończeniu pobierz `RouletteVision-APK` i wypakuj `app-debug.apk`.
4. Zainstaluj APK na Androidzie. W przypadku konfliktu podpisu mogą być potrzebne nowe dane/backup przed odinstalowaniem starej aplikacji.
