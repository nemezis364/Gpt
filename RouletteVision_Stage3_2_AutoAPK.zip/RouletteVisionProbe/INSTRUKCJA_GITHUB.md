# Roulette Vision PRO 3.2

1. Wgraj `RouletteVision_Stage3_2_AutoAPK.zip` do repozytorium `Gpt`.
2. W pliku `.github/workflows/build-apk.yml` zmień tylko linię rozpakowywania na:

```yaml
      - name: Rozpakuj projekt
        run: unzip -q RouletteVision_Stage3_2_AutoAPK.zip
```

3. Zapisz zmiany. GitHub Actions zbuduje APK i udostępni je jako `RouletteVision-APK`.
4. Testuj automatyczne odczyty w Coldbet i korzystaj z ręcznej korekty, jeśli ekran jest nieczytelny.
