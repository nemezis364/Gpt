package pl.roulette.visionprobe;

import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.ArrayDeque;

/** Disambiguates 6/9 using the vertical position of the inner hole in a bright glyph. */
final class SixNineShape {
    private SixNineShape(){}
    static int read(Bitmap bitmap,Rect tile,boolean twoDigit){
        if(bitmap==null||bitmap.isRecycled()||tile==null)return -1;
        int w=bitmap.getWidth(),h=bitmap.getHeight(),tw=tile.width(),th=tile.height();
        if(tw<35||th<18)return -1;
        // Inspect only the last digit, not the number background or its border.
        int x0=Math.max(0,tile.left+(int)(tw*(twoDigit?.49:.20)));
        int x1=Math.min(w,tile.left+(int)(tw*.87));
        int y0=Math.max(0,tile.top+(int)(th*.12));
        int y1=Math.min(h,tile.bottom-(int)(th*.12));
        int ww=x1-x0,hh=y1-y0;if(ww<10||hh<10)return -1;
        int[] pixels=new int[ww*hh];bitmap.getPixels(pixels,0,ww,x0,y0,ww,hh);
        byte[] ink=new byte[ww*hh],visited=new byte[ww*hh];
        for(int i=0;i<pixels.length;i++){
            int p=pixels[i],r=(p>>16)&255,g=(p>>8)&255,b=p&255;
            // Winning number text is near-white on red/black/grey tile.
            if(r>165&&g>154&&b>148&&Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b))<70)ink[i]=1;
        }
        // Extract largest connected white character (removes detached highlights/noise).
        int[] q=new int[ink.length];int bestArea=0,bx0=0,by0=0,bx1=0,by1=0;
        for(int i=0;i<ink.length;i++){
            if(ink[i]==0||visited[i]!=0)continue;
            int head=0,tail=0;visited[i]=1;q[tail++]=i;
            int left=ww,top=hh,right=0,bottom=0;
            while(head<tail){
                int p=q[head++],x=p%ww,y=p/ww;
                left=Math.min(left,x);right=Math.max(right,x);
                top=Math.min(top,y);bottom=Math.max(bottom,y);
                for(int yy=Math.max(0,y-1);yy<=Math.min(hh-1,y+1);yy++)
                    for(int xx=Math.max(0,x-1);xx<=Math.min(ww-1,x+1);xx++){
                        int j=yy*ww+xx;
                        if(ink[j]!=0&&visited[j]==0){visited[j]=1;q[tail++]=j;}
                    }
            }
            if(tail>bestArea){bestArea=tail;bx0=left;by0=top;bx1=right;by1=bottom;}
        }
        int bw=bx1-bx0+1,bh=by1-by0+1;
        if(bestArea<20||bw<5||bh<9)return -1;
        if((double)bw/bh<.30||(double)bw/bh>1.5)return -1;
        // Recreate the chosen glyph's whiteness in its tight rectangle.
        int gw=bw+2,gh=bh+2;byte[] glyph=new byte[gw*gh];
        for(int y=0;y<bh;y++)for(int x=0;x<bw;x++)
            glyph[(y+1)*gw+x+1]=ink[(by0+y)*ww+bx0+x];
        // Flood-fill exterior background from glyph rectangle border; untouched dark
        // components are enclosed holes. 6 and 9 have one hole at opposite ends.
        byte[] outside=new byte[glyph.length];ArrayDeque<Integer> queue=new ArrayDeque<>();
        for(int x=0;x<gw;x++){
            push(x,0,gw,glyph,outside,queue);push(x,gh-1,gw,glyph,outside,queue);
        }
        for(int y=0;y<gh;y++){
            push(0,y,gw,glyph,outside,queue);push(gw-1,y,gw,glyph,outside,queue);
        }
        while(!queue.isEmpty()){
            int p=queue.removeFirst(),x=p%gw,y=p/gw;
            if(x>0)push(x-1,y,gw,glyph,outside,queue);
            if(x<gw-1)push(x+1,y,gw,glyph,outside,queue);
            if(y>0)push(x,y-1,gw,glyph,outside,queue);
            if(y<gh-1)push(x,y+1,gw,glyph,outside,queue);
        }
        int holeArea=0;long sumY=0;
        for(int y=1;y<gh-1;y++)for(int x=1;x<gw-1;x++){
            int i=y*gw+x;
            if(glyph[i]==0&&outside[i]==0){holeArea++;sumY+=y-1;}
        }
        if(holeArea<Math.max(3,bw*bh/55))return -1;
        double holePosition=(sumY/(double)holeArea)/Math.max(1,bh-1);
        if(holePosition>=.56)return 6;
        if(holePosition<=.44)return 9;
        return -1;
    }
    private static void push(int x,int y,int width,byte[] glyph,byte[] seen,ArrayDeque<Integer> q){
        int i=y*width+x;
        if(glyph[i]==0&&seen[i]==0){seen[i]=1;q.addLast(i);}
    }
}
