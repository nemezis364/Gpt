package pl.roulette.visionprobe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Faithful port of the TOP 1 CCW + historical 3×5 model from the last HTML version. */
public final class ForecastMath {
    private ForecastMath() {}
    public static final int[] WHEEL = {0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26};
    private static final int[] INDEX = new int[37];
    static { for (int i=0;i<37;i++) INDEX[WHEEL[i]]=i; }
    public static boolean valid(int n) { return n>=0 && n<=36; }
    public static int distance(int a,int b) {
        int step=(INDEX[b]-INDEX[a]+37)%37;
        return Math.min(step,37-step);
    }
    public static int[] neighbors(int center) {
        int pos=INDEX[center];
        int[] out=new int[5];
        for(int k=0;k<5;k++)out[k]=WHEEL[(pos+k-2+37)%37];
        return out;
    }
    public static class Top {
        public final int number, distance, frequency;
        public final int[] four;
        Top(int n,int d,int f,int[] four){number=n;distance=d;frequency=f;this.four=four;}
    }
    public static Top top1(List<Integer> spins,int prefix){
        if(prefix<5)return null;
        int[] four=new int[4],freq=new int[19],latest=new int[19];
        Arrays.fill(latest,-1);
        for(int i=0;i<4;i++){
            four[i]=distance(spins.get(prefix-5+i),spins.get(prefix-4+i));
            if(four[i]>0){freq[four[i]]++;latest[four[i]]=i;}
        }
        int best=0;
        for(int d=1;d<=18;d++)if(freq[d]>freq[best] || (freq[d]==freq[best] && latest[d]>latest[best]))best=d;
        if(best==0)return new Top(-1,0,4,four);
        // Negative direction in the standard European physical WHEEL list = CCW.
        int next=WHEEL[(INDEX[spins.get(prefix-1)]-best+37)%37];
        return new Top(next,best,freq[best],four);
    }
    /** Uses ONLY earlier TOP1 predictions. It may not read prediction at the trigger spin or later. */
    public static int[] historyCenters(int actual,List<Integer> spins,int prefix){
        ArrayList<Integer> stream=new ArrayList<>();
        for(int p=5;p<prefix;p++){
            Top t=top1(spins,p);
            if(t!=null && t.number>=0)stream.add(t.number);
        }
        int[] selected=null;
        for(int i=0;i+3<stream.size();i++)if(stream.get(i)==actual)
            selected=new int[]{stream.get(i+1),stream.get(i+2),stream.get(i+3)};
        return selected;
    }
    private static int wheelGap(int i,int j){int x=Math.abs(i-j);return Math.min(x,37-x);}
    private static boolean disjoint(int i,int j){return wheelGap(i,j)>=5;}
    /** Minimal adjustment: first fewest shifted sectors, then smallest total movement, then original order. */
    public static int[] noOverlap(int[] raw){
        if(raw==null||raw.length!=3)return null;
        int[] pos={INDEX[raw[0]],INDEX[raw[1]],INDEX[raw[2]]};
        int[] key=null, chosen=null;
        for(int a=0;a<37;a++)for(int b=0;b<37;b++){
            if(!disjoint(a,b))continue;
            for(int c=0;c<37;c++){
                if(!disjoint(a,c)||!disjoint(b,c))continue;
                int d0=wheelGap(pos[0],a),d1=wheelGap(pos[1],b),d2=wheelGap(pos[2],c);
                int[] next={((d0>0)?1:0)+((d1>0)?1:0)+((d2>0)?1:0),d0+d1+d2,d0,d1,d2,a,b,c};
                if(key==null||less(next,key)){
                    key=next;chosen=new int[]{WHEEL[a],WHEEL[b],WHEEL[c]};
                }
            }
        }
        return chosen;
    }
    private static boolean less(int[] a,int[] b){for(int i=0;i<a.length;i++){if(a[i]!=b[i])return a[i]<b[i];}return false;}
    public static int[] sectorNumbers(int[] centers){
        if(centers==null||centers.length!=3)return new int[0];
        int[] numbers=new int[15];int off=0;
        for(int c:centers)for(int n:neighbors(c))numbers[off++]=n;
        return numbers;
    }
    public static int countDozen(List<Integer> spins,int end,int from,int to,int window){
        int found=0;
        for(int i=Math.max(0,end-window);i<end;i++){
            int n=spins.get(i);if(n>=from&&n<=to)found++;
        }
        return found;
    }
    /** Returns leading historical dozen (1..3), not a genuine probability forecast. */
    public static int hotDozen(List<Integer> spins,int window){
        if(spins.isEmpty())return 0;
        int end=spins.size(),best=0,bestCount=-1,bestRecency=-1;
        for(int d=1;d<=3;d++){
            int from=(d-1)*12+1,to=d*12;
            int count=countDozen(spins,end,from,to,window);
            int last=-1;for(int i=end-1;i>=Math.max(0,end-window);i--)if(spins.get(i)>=from&&spins.get(i)<=to){last=i;break;}
            if(count>bestCount||(count==bestCount&&last>bestRecency)) {best=d;bestCount=count;bestRecency=last;}
        }
        return best;
    }
    /** 0=even,1=odd, -1=not enough nonzero data. */
    public static int hotParity(List<Integer> spins,int window){
        int start=Math.max(0,spins.size()-window),even=0,odd=0,lastEven=-1,lastOdd=-1;
        for(int i=start;i<spins.size();i++){
            int n=spins.get(i);if(n==0)continue;
            if(n%2==0){even++;lastEven=i;}else{odd++;lastOdd=i;}
        }
        if(even+odd==0)return -1;
        return even>odd?0:odd>even?1:lastEven>lastOdd?0:1;
    }
}
