package pl.roulette.visionprobe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Main control panel. Predictions are calculated even when the user opens Coldbet. */
public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN=4101, REQUEST_IMPORT=4102;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private PredictionEngine engine;
    private TextView status,forecast,history,permissions;
    private EditText manual;
    private Spinner dealerSpinner;
    private boolean changingDealers=false;
    private final Runnable ticker=new Runnable(){@Override public void run(){refresh();handler.postDelayed(this,850);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);engine=new PredictionEngine(this);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xFF0B1220);
        LinearLayout root=new LinearLayout(this);root.setPadding(dp(18),dp(26),dp(18),dp(24));root.setOrientation(LinearLayout.VERTICAL);scroll.addView(root);setContentView(scroll);
        root.addView(label("🎯 ROULETTE VISION PRO 3.2",25,0xFFEEF6FC,true));
        root.addView(label("TOP 1 CCW → historia → 3 sektory × 5 kieszeni",14,0xFF6CE0B7,true));root.addView(gap(10));
        root.addView(label("Automatyczny odczyt WYŁĄCZNIE wyróżnionego numeru w górnym pasku wyników Coldbet (po lewej w pionie). Zasłoniętego ruchu kulki już nie analizujemy. Zielone pole oznacza 0, a 6/9 przechodzi kontrolę kształtu. Niepewne odczyty możesz poprawić ręcznie.",14,0xFFB2C4DB,false));root.addView(gap(14));
        Button overlay=button("1. Zezwól na okno nad Coldbet",0xFF176DBA);overlay.setOnClickListener(v->requestOverlay());root.addView(overlay);
        permissions=label("",12,0xFFC5D5E7,false);root.addView(permissions);root.addView(gap(8));
        Button start=button("2. Rozpocznij automatyczny odczyt",0xFF148354);start.setOnClickListener(v->requestCapture());root.addView(start);
        Button stop=button("Zatrzymaj przechwytywanie",0xFF98384C);stop.setOnClickListener(v->{Intent i=new Intent(this,CaptureService.class);i.setAction(CaptureService.ACTION_STOP);startService(i);});root.addView(stop);
        root.addView(gap(16));
        root.addView(label("PROFIL STOŁU / KRUPIERA",13,0xFF6CE0B7,true));
        dealerSpinner=new Spinner(this);dealerSpinner.setBackgroundTintList(ColorStateList.valueOf(0xFFEAF2FB));root.addView(dealerSpinner);populateDealers();
        dealerSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(changingDealers)return;String name=(String)p.getItemAtPosition(pos);engine=new PredictionEngine(MainActivity.this);engine.selectDealer(name);refresh();}
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        Button addDealer=button("Dodaj profil / krupiera",0xFF284460);addDealer.setOnClickListener(v->newDealer());root.addView(addDealer);
        root.addView(gap(13));
        root.addView(label("AKTUALNE TYPOWANIA I STATYSTYKI",13,0xFF6CE0B7,true));
        root.addView(label("SEKTORY 3×5: po trafieniu poprzedniej prognozy pokaż następną; po nietrafieniu ukryj. Model nadal ocenia ukryte typy w tle.",12,0xFFF0C56B,false));
        forecast=label("",15,0xFFF1F6FC,false);forecast.setTypeface(Typeface.MONOSPACE);
        forecast.setBackgroundColor(0xFF192A41);forecast.setPadding(dp(12),dp(12),dp(12),dp(12));root.addView(forecast);
        root.addView(gap(10));
        root.addView(label("STATUS OCR",13,0xFF6CE0B7,true));
        status=label("",13,0xFFB7CFDF,false);root.addView(status);root.addView(gap(12));
        root.addView(label("KOREKTA / RĘCZNY WYNIK",13,0xFF6CE0B7,true));
        LinearLayout inline=new LinearLayout(this);inline.setOrientation(LinearLayout.HORIZONTAL);
        manual=new EditText(this);manual.setHint("0–36");manual.setTextColor(Color.WHITE);manual.setHintTextColor(0xFF8293A3);manual.setInputType(InputType.TYPE_CLASS_NUMBER);manual.setSingleLine(true);
        inline.addView(manual,new LinearLayout.LayoutParams(0,dp(54),1f));
        Button add=button("Dodaj numer",0xFF176DBA);inline.addView(add);
        add.setOnClickListener(v->{engine=new PredictionEngine(this);try{int n=Integer.parseInt(manual.getText().toString().trim());if(!engine.record(n,"ręcznie"))throw new Exception();manual.setText("");refresh();}catch(Exception ex){new AlertDialog.Builder(this).setMessage("Wpisz numer całkowity od 0 do 36.").setPositiveButton("OK",null).show();}});
        root.addView(inline);
        Button undo=button("Cofnij ostatni zapis",0xFF634352);undo.setOnClickListener(v->{engine=new PredictionEngine(this);engine.undo();refresh();});root.addView(undo);
        Button importFile=button("Importuj historię JSON z dawnej aplikacji HTML",0xFF284460);
        importFile.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQUEST_IMPORT);});root.addView(importFile);
        root.addView(gap(11));
        root.addView(label("OSTATNIE WYNIKI",13,0xFF6CE0B7,true));history=label("",14,0xFFDCE8F4,false);root.addView(history);
        root.addView(gap(18));
        root.addView(label("Ważne",14,0xFFF0C56B,true));root.addView(label("Odczyt OCR może pomylić wynik z liczbami w pasku historii. Każdy automatyczny numer sprawdź w trakcie testów, zanim użyjesz statystyk. Zero nie należy ani do tuzinów, ani do parzystych/nieparzystych. Strategia liczy tylko historyczne wystąpienia; nie daje matematycznej przewagi nad ruletką. 15 kieszeni = 40,54% szansy trafienia w uczciwej ruletce.",13,0xFFBDCADB,false));
    }
    private void populateDealers(){changingDealers=true;List<String> names=engine.dealerNames();ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);dealerSpinner.setAdapter(adapter);int pos=names.indexOf(engine.getSelected());dealerSpinner.setSelection(Math.max(0,pos));changingDealers=false;}
    private void newDealer(){engine=new PredictionEngine(this);EditText input=new EditText(this);input.setHint("np. Auto Roulette, Krupier A");new AlertDialog.Builder(this).setTitle("Nazwa profilu").setView(input).setNegativeButton("Anuluj",null).setPositiveButton("Dodaj",(d,w)->{engine.addDealer(input.getText().toString());populateDealers();refresh();}).show();}
    private void requestOverlay(){if(Settings.canDrawOverlays(this)){refresh();return;}startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}
    private void requestCapture(){try{MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),REQUEST_SCREEN);}catch(Exception e){status.setText("Błąd zgody: "+e.getMessage());}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_SCREEN){if(resultCode!=RESULT_OK||data==null){status.setText("Przechwytywanie anulowane.");return;}
            Intent s=new Intent(this,CaptureService.class);s.setAction(CaptureService.ACTION_START);s.putExtra(CaptureService.EXTRA_RESULT_CODE,resultCode);s.putExtra(CaptureService.EXTRA_RESULT_DATA,data);
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)startForegroundService(s);else startService(s);
        }else if(requestCode==REQUEST_IMPORT && resultCode==RESULT_OK&&data!=null){
            try(InputStream is=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096];int n;while((n=is.read(buf))>=0)out.write(buf,0,n);
                String json=new String(out.toByteArray(),StandardCharsets.UTF_8);
                new AlertDialog.Builder(this).setTitle("Zastąpić historię?").setMessage("Import zmieni zapisane numery i usunie bieżące statystyki prognoz. Historyczne trafienia będą odtwarzane wyłącznie w trybie testowym.")
                    .setNegativeButton("Anuluj",null).setPositiveButton("Importuj",(d,w)->{
                        engine=new PredictionEngine(this);if(!engine.importJson(json))status.setText("Błędny plik JSON.");refresh();
                    }).show();
            }catch(Exception e){status.setText("Nie udało się odczytać JSON: "+e.getMessage());}
        }
    }
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
    private void refresh(){if(forecast==null)return;PredictionEngine current=new PredictionEngine(this);
        forecast.setText(current.summary());history.setText(current.recent());
        permissions.setText(Settings.canDrawOverlays(this)?"✓ Nakładka: dozwolona":"○ Nakładka: wymaga zezwolenia");
        status.setText(getSharedPreferences(CaptureService.PREFS,MODE_PRIVATE).getString(CaptureService.KEY_STATUS,"Przechwytywanie nieuruchomione"));
    }
    private TextView label(String t,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(5),0,dp(5));if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private Button button(String text,int col){Button b=new Button(this);b.setText(text);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(ColorStateList.valueOf(col));return b;}
    private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
