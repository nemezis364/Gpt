package pl.roulette.visionprobe;

import android.media.Image;
import java.nio.ByteBuffer;

/**
 * Lightweight, offline screen-capture diagnostics (not yet a roulette tracker).
 * Samples the central screen without retaining pixels or writing images to disk.
 */
public final class FrameAnalyzer {
    private static final int COLS = 36;
    private static final int ROWS = 28;
    private int[] previous;
    private int previousWidth = -1;
    private int previousHeight = -1;

    public static final class Reading {
        public final double meanBrightness;
        public final double changePercent;
        public final double darkPercent;
        Reading(double meanBrightness, double changePercent, double darkPercent) {
            this.meanBrightness = meanBrightness;
            this.changePercent = changePercent;
            this.darkPercent = darkPercent;
        }
    }

    public Reading analyze(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return new Reading(0, 0, 100);
        Image.Plane p = planes[0];
        final ByteBuffer b = p.getBuffer();
        final int width = image.getWidth();
        final int height = image.getHeight();
        final int pixelStride = p.getPixelStride();
        final int rowStride = p.getRowStride();
        if (width < 2 || height < 2 || pixelStride < 3) return new Reading(0, 0, 100);

        if (width != previousWidth || height != previousHeight) {
            previous = null;
            previousWidth = width;
            previousHeight = height;
        }
        int[] values = new int[COLS * ROWS];
        int moved = 0;
        int dark = 0;
        long brightSum = 0;
        int maxIndex = b.limit() - 3;
        // Sample 10%-90% of X and Y, not the status / navigation bars.
        for (int row = 0; row < ROWS; row++) {
            int y = Math.min(height - 1, (int) (height * (0.10 + 0.80 * (row + 0.5) / ROWS)));
            for (int col = 0; col < COLS; col++) {
                int x = Math.min(width - 1, (int) (width * (0.10 + 0.80 * (col + 0.5) / COLS)));
                int index = y * rowStride + x * pixelStride;
                if (index < 0 || index > maxIndex) continue;
                int r = b.get(index) & 0xFF;
                int g = b.get(index + 1) & 0xFF;
                int bl = b.get(index + 2) & 0xFF;
                int luminance = (54 * r + 183 * g + 19 * bl) >> 8;
                int at = row * COLS + col;
                values[at] = luminance;
                brightSum += luminance;
                if (luminance < 13) dark++;
                if (previous != null && Math.abs(previous[at] - luminance) > 16) moved++;
            }
        }
        previous = values;
        int sampleCount = values.length;
        return new Reading(brightSum / (double) sampleCount,
                moved * 100.0 / sampleCount, dark * 100.0 / sampleCount);
    }
}
