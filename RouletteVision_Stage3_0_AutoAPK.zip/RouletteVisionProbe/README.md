# Roulette Vision PRO 3.0 — wersja testowa Android

Zbudowana na bazie przetestowanej aplikacji Roulette Vision 2.2. Ten projekt **nie jest jeszcze APK**, lecz kompletnym projektem do skompilowania przez GitHub Actions.

## Co robi

- Zachowuje algorytm ostatniej aplikacji HTML `ruletka_europejska_pro_TOP1_CCW_4_odleglosci_3x5_40proc_6.html`:
  - analiza czterech ostatnich bezkierunkowych odległości między pięcioma ostatnimi wynikami;
  - wybór najczęściej występującej niezerowej odległości, przy remisie najnowszej;
  - **jeden numer TOP 1 odliczony w kierunku CCW** na fizycznym kole;
  - zapis TOP 1 po każdym spinie do historii;
  - szukanie najnowszego wcześniejszego wystąpienia ostatniego wyniku w strumieniu TOP 1, po którym są trzy dalsze historyczne liczby;
  - trzy liczby wyznaczają środki trzech sektorów pięciokieszeniowych;
  - minimalna korekta nakładających się sektorów dla **15 różnych numerów**;
  - 3×5 widoczne dopiero po minimum **3 trafieniach z 6 rozliczonych prognoz** tego profilu (minimum 40% warunku przy 6 próbach).
- Dwa dodatkowe niezależne moduły **historycznych częstotliwości**: tuzin 1–12 / 13–24 / 25–36 i parzyste / nieparzyste, liczone z ostatnich 12 spinów. Zero jest wyłączone.
- Pokazuje numer TOP 1, trzy sektory i dwa dodatkowe moduły w niedotykalnej nakładce nad Coldbet, wyłącznie po zgodzie na wyświetlanie nad aplikacjami.
- **Próbuje** automatycznie rozpoznawać zwycięski numer z wyróżnionego pola w górnym pasku wyników Coldbet. Korzysta z Google ML Kit — model OCR znajduje się w APK, nie wysyła klatek na serwer. Program nie próbuje już obserwować kulki.
- Nie akceptuje pojedynczej niepewnej klatki: wymaga rozpoznania co najmniej dwóch sąsiednich numerów historii, 3 kolejnych zgodnych rozpoznań oraz zmiany sygnatury paska.
- Pozwala poprawić wynik ręcznie, cofnąć ostatni zapis i zaimportować historię z pliku JSON ze starego HTML. Import nie odtwarza fikcyjnych rozliczonych zakładów z przeszłości.
- Pozwala prowadzić osobne profile krupierów / stołów.
- Działa na jednym urządzeniu, po uzyskaniu zgody Androida na przechwytywanie całego ekranu.

## Ograniczenia

**Uwaga: automatyczne rozpoznawanie ostatniego numeru jest nowym prototypem, jeszcze nieprzetestowanym w Coldbet.** Układ paska i czcionki mogą uniemożliwić OCR albo spowodować błędy. Zweryfikuj każdą automatycznie dodaną liczbę. Gdy numer jest błędny, możesz cofnąć i wpisać poprawny.

Odczyt ze zrzutu ekranu zależy od aplikacji Coldbet, orientacji, rozdzielczości oraz widoczności paska ostatniego wyniku. Nie gwarantuje działania przy zabezpieczeniach zrzutów ekranu. Nie steruje aplikacją kasyna ani nie stawia zakładów.

Strategie oparte na historii **nie zwiększają teoretycznego prawdopodobieństwa** uczciwej ruletki: 15/37 (40,54%) dla 15 różnych numerów, 12/37 (32,43%) dla tuzina, 18/37 (48,65%) dla parzystych/nieparzystych.

## Budowanie APK bez komputera

1. Wgraj `RouletteVision_Stage3_0_AutoAPK.zip` do repozytorium https://github.com/nemezis364/Gpt
2. W `.github/workflows/build-apk.yml` zmień **jedynie** linię rozpakowującą na:

   `run: unzip -q RouletteVision_Stage3_0_AutoAPK.zip`

3. Zatwierdź przez `Commit changes`.
4. W Actions znajdziesz artefakt `RouletteVision-APK` po udanej kompilacji. ZIP artefaktu zawiera `app-debug.apk`.

Projekt z archiwum ma katalog główny `RouletteVisionProbe`, aby pasował do dotychczasowego workflow GitHub Actions.

## Bezpieczeństwo i prywatność

Żadna klatka ekranu nie jest zapisywana ani wysyłana. Przechwytywanie ekranu wymaga zgody Androida na każdą nową sesję. Nakładka nie przechwytuje dotyku. Wszystkie odczyty i prognozy zapisują się w prywatnej pamięci aplikacji (SharedPreferences).
