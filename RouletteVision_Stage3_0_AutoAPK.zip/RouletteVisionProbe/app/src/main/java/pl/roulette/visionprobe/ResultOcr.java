package pl.roulette.visionprobe;

import android.graphics.Bitmap;
import android.media.Image;
import android.os.SystemClock;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Prototype: reads highlighted last result in Coldbet's upper history strip.
 * Does NOT detect the ball, track betting, or place bets.
 * Needs on-device verification; will decline to add a number if uncertain.
 */
public final class ResultOcr {
    public interface Listener { void onRead(int number, String stripSignature, String diagnostic); void onUncertain(String diagnostic); }
    private static final Pattern INTEGER=Pattern.compile("(?:[0-9]|[12][0-9]|3[0-6])");
    private final TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private final Listener listener;
    private volatile boolean busy=false;
    private long lastAttempt=0;
    public ResultOcr(Listener listener){this.listener=listener;}

    public void capture(Image image){
        long now=SystemClock.elapsedRealtime();
        if(busy||now-lastAttempt<900)return;
        lastAttempt=now;busy=true;
        try{
            if(!hasWoodenWheelColors(image)){
                listener.onUncertain("Brak widocznego koła Coldbet — odczyt wyłączony poza transmisją");
                busy=false;return;
            }
            Bitmap bitmap=extractHeader(image);
            if(bitmap==null){busy=false;return;}
            // Bundled Latin recognition runs locally and does not upload image pixels.
            Task<Text> task=recognizer.process(InputImage.fromBitmap(bitmap,0));
            task.addOnSuccessListener(text->parse(text,bitmap.getWidth(),bitmap.getHeight()))
                .addOnFailureListener(error->listener.onUncertain("OCR niedostępny: "+error.getClass().getSimpleName()))
                .addOnCompleteListener(t->{busy=false;bitmap.recycle();});
        }catch(Exception e){busy=false;listener.onUncertain("Błąd odczytu: "+e.getClass().getSimpleName());}
    }

    /** Avoid interpreting unrelated app interfaces as Coldbet results. Sample warm wheel pixels. */
    private boolean hasWoodenWheelColors(Image image){
        Image.Plane[] planes=image.getPlanes();if(planes.length==0)return false;
        ByteBuffer b=planes[0].getBuffer();int w=image.getWidth(),h=image.getHeight();
        int ps=planes[0].getPixelStride(),rs=planes[0].getRowStride();
        if(w<100||h<150||ps<3)return false;
        int total=0,warm=0,limit=b.limit();
        for(int y=(int)(h*.15);y<(int)(h*.90);y+=Math.max(3,h/45))
            for(int x=(int)(w*.12);x<(int)(w*.87);x+=Math.max(3,w/52)){
                int p=y*rs+x*ps;if(p+2>=limit)continue;
                int r=b.get(p)&255,g=b.get(p+1)&255,bl=b.get(p+2)&255;
                total++;
                if(r>78&&g>28&&r>g*1.28&&g>bl*1.15)warm++;
            }
        return total>0 && (warm*100.0/total)>4.8;
    }

    /** Crop only upper results strip; never retain full screenshots on disk. */
    private Bitmap extractHeader(Image image){
        int w=image.getWidth(),h=image.getHeight();if(w<100||h<150)return null;
        Image.Plane[] planes=image.getPlanes();if(planes.length==0)return null;
        ByteBuffer b=planes[0].getBuffer();int ps=planes[0].getPixelStride(),rs=planes[0].getRowStride();
        if(ps<3)return null;
        // Results highlight is near the horizontal middle in both portrait and landscape.
        int x0=(int)(w*.39),x1=(int)(w*.97),y0=(int)(h*.006),y1=(int)(h*(w>h?.31:.24));
        int cw=x1-x0,ch=y1-y0;int[] pixels=new int[cw*ch];int limit=b.limit();
        for(int y=0;y<ch;y++)for(int x=0;x<cw;x++){
            int idx=(y+y0)*rs+(x+x0)*ps;if(idx+2>=limit)continue;
            int r=b.get(idx)&255,g=b.get(idx+1)&255,bl=b.get(idx+2)&255;
            pixels[y*cw+x]=0xFF000000|(r<<16)|(g<<8)|bl;
        }
        Bitmap bm=Bitmap.createBitmap(cw,ch,Bitmap.Config.ARGB_8888);
        bm.setPixels(pixels,0,cw,0,0,cw,ch);
        return bm;
    }
    private static class Digit {int n,x,y;Digit(int n,int x,int y){this.n=n;this.x=x;this.y=y;}}
    private void parse(Text text,int w,int h){
        List<Digit> items=new ArrayList<>();
        for(Text.TextBlock block:text.getTextBlocks())for(Text.Line line:block.getLines())for(Text.Element el:line.getElements()){
            String raw=el.getText().replaceAll("[^0-9]","");
            // If original text has currency/decimal separators, don't interpret it as a winning number.
            if(!INTEGER.matcher(raw).matches() || !el.getText().trim().matches("[0-9]{1,2}"))continue;
            if(el.getBoundingBox()==null)continue;
            int n=Integer.parseInt(raw);
            items.add(new Digit(n,el.getBoundingBox().centerX(),el.getBoundingBox().centerY()));
        }
        if(items.isEmpty()){listener.onUncertain("Nie odczytano numeru w górnym pasku");return;}
        // Crop starts at 39% screen width; true highlighted result is near 50% global width.
        final double highlightedX=w*((.50-.39)/(.97-.39));
        Digit lead=null;double best=Double.POSITIVE_INFINITY;
        for(Digit d:items){
            double dx=Math.abs(d.x-highlightedX)/Math.max(1,w);
            if(dx>.19)continue;
            // Top widgets (wallet) occasionally contain decimals and are already rejected.
            double cost=dx+0.07*(d.y/(double)h);
            if(cost<best){best=cost;lead=d;}
        }
        if(lead==null){listener.onUncertain("Numer poza obszarem ostatniego wyniku");return;}
        List<Digit> line=new ArrayList<>();
        for(Digit d:items)if(Math.abs(d.y-lead.y)<Math.max(14,h*.095) && d.x>=lead.x-12)line.add(d);
        Collections.sort(line,Comparator.comparingInt(d->d.x));
        StringBuilder signature=new StringBuilder();int count=0;
        for(Digit d:line){if(count>=6)break;if(count>0)signature.append('-');signature.append(d.n);count++;}
        if(count<3){listener.onUncertain("OCR widzi "+lead.n+", ale wymaga co najmniej dwóch liczb historii");return;}
        listener.onRead(lead.n,signature.toString(),"Odczyt paska: "+signature);
    }
    public void close(){recognizer.close();}
}
