# Roulette Vision PRO 3.0 — kompilacja na telefonie

Projekt w archiwum jest przygotowany dla repozytorium `nemezis364/Gpt`. Nie wysyłaj tu żadnych haseł ani danych konta Coldbet.

1. Wgraj `RouletteVision_Stage3_0_AutoAPK.zip`: https://github.com/nemezis364/Gpt/upload/main
2. Edytuj https://github.com/nemezis364/Gpt/edit/main/.github/workflows/build-apk.yml
3. W kroku `Rozpakuj projekt` wstaw dokładnie:

```yaml
      - name: Rozpakuj projekt
        run: unzip -q RouletteVision_Stage3_0_AutoAPK.zip
```

4. Zapisz `Commit changes`.
5. Otwórz https://github.com/nemezis364/Gpt/actions — wybierz nową kompilację i w `Artifacts` pobierz `RouletteVision-APK`.
6. Rozpakuj pobrane archiwum i zainstaluj `app-debug.apk` (Android może poprosić o zgodę na instalację spoza sklepu).

W tej wersji OCR oraz typowania są eksperymentalne. Nie przeprowadziłem jeszcze testu odczytu numeru w rzeczywistej aplikacji Coldbet.
