# Roulette Vision — etap 2.2 (diagnostyka odsłoniętego pierścienia)

Zmiany względem 2.1:
- Mniejsza nakładka na dole ekranu, poza górnym widocznym fragmentem fizycznego koła.
- Bufor do 1440 px na dłuższym boku i analiza kandydata co ok. 60 ms.
- W trybie pionowym ignorowanie dolnej części ekranu, gdzie zwykle znajduje się tor obstawiania Coldbet.
- Szersza strefa próbkowania zewnętrznego toru, na którym porusza się kulka.
- Zielony kandydat wymaga ruchu; stała zielona kieszeń na torze obstawiania nie liczy się jako ruchome zero.

## Ograniczenia
To eksperymentalny wykrywacz kandydatów, NIE potwierdzony tracker kulki ani system predykcji. Nie potrafi analizować ukrytych pikseli: gdy UI Coldbet zasłania kulkę, trzeba zmienić widok w Coldbet. Nie używać do obstawiania.

## GitHub
Wgraj `RouletteVision_Stage2_2_AutoAPK.zip` do repozytorium i zmień w `.github/workflows/build-apk.yml` linię na:
`run: unzip -q RouletteVision_Stage2_2_AutoAPK.zip`
